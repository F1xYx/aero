import { useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Home, MoreHorizontal, RotateCw, ShieldCheck, X, Download, Puzzle } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Omnibox } from "./Omnibox";
import { ShieldPopover } from "./ShieldPopover";
import { MainMenu } from "./MainMenu";
import { useOutside } from "./ui";
import { isInternal } from "../lib/url";
import { cn } from "../utils/cn";

export function Toolbar() {
  const b = useBrowser();
  const { active } = b;
  const [pop, setPop] = useState<null | "shield" | "menu">(null);
  const shieldRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  useOutside(shieldRef, () => pop === "shield" && setPop(null), pop === "shield");
  useOutside(menuRef, () => pop === "menu" && setPop(null), pop === "menu");

  const canBack = active.pos > 0;
  const canFwd = active.pos < active.stack.length - 1;
  const url = active.stack[active.pos];
  const s = b.settings;
  const protectedAll = s.blockAds && s.httpsOnly && s.dnt;
  const installed = Object.values(b.extensions).filter(Boolean).length;

  return (
    <div className="no-select relative flex items-center gap-1 h-[46px] px-2.5 flex-none" style={{ background: "var(--toolbar-bg)", borderBottom: "1px solid var(--hairline)" }}>
      <button className="ibtn" disabled={!canBack} onClick={() => b.go(-1)} aria-label="Назад" title="Назад (Alt+←)"><ArrowLeft size={18} /></button>
      <button className="ibtn" disabled={!canFwd} onClick={() => b.go(1)} aria-label="Вперёд" title="Вперёд (Alt+→)"><ArrowRight size={18} /></button>
      <button
        className="ibtn" onClick={() => (active.loading ? b.stop() : b.reload())}
        aria-label={active.loading ? "Остановить" : "Обновить"} title={active.loading ? "Остановить" : "Обновить (F5)"}
      >
        {active.loading ? <X size={17} /> : <RotateCw size={16} />}
      </button>
      <button className="ibtn" onClick={b.goHome} aria-label="Домой" title="Домой (Alt+Home)"><Home size={17} /></button>

      <div className="flex-1 min-w-0 flex px-2"><Omnibox /></div>

      <div ref={shieldRef} className="relative">
        <button className={cn("ibtn", pop === "shield" && "on")} onClick={() => setPop(pop === "shield" ? null : "shield")} aria-label="Защита" title="Защита Aera">
          <ShieldCheck size={18} style={{ color: protectedAll ? "var(--ok)" : "var(--text-2)" }} />
          {!isInternal(url) && active.blocked > 0 && (
            <span className="absolute -top-px -right-px min-w-[15px] h-[15px] px-1 rounded-full text-[9.5px] font-bold text-white flex items-center justify-center tabular-nums" style={{ background: "var(--accent)" }}>
              {active.blocked > 99 ? "99+" : active.blocked}
            </span>
          )}
        </button>
        {pop === "shield" && <ShieldPopover />}
      </div>
      <button className="ibtn relative" onClick={() => b.openPage("aera://extensions")} aria-label="Расширения" title="Расширения">
        <Puzzle size={17} />
        {installed > 0 && <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full" style={{ background: "var(--accent)" }} />}
      </button>
      <button className="ibtn" onClick={() => b.openPage("aera://downloads")} aria-label="Загрузки" title="Загрузки (Ctrl+J)"><Download size={17} /></button>
      <div ref={menuRef} className="relative">
        <button className={cn("ibtn", pop === "menu" && "on")} onClick={() => setPop(pop === "menu" ? null : "menu")} aria-label="Меню" title="Меню">
          <MoreHorizontal size={19} />
        </button>
        {pop === "menu" && <MainMenu close={() => setPop(null)} />}
      </div>

      {active.loading && <div className="progress" />}
    </div>
  );
}
