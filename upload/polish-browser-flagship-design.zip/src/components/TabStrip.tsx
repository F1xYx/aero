import { useRef, useState } from "react";
import {
  Copy, EyeOff, Maximize2, Minus, Moon, Pin, PinOff, Plus, RotateCw, Square, Volume2, VolumeX, X, History,
} from "lucide-react";
import { useBrowser } from "../store/browser";
import { PageIcon } from "./PageIcon";
import { Logo } from "./ui";
import { ContextMenu, type MenuEntry } from "./ContextMenu";
import { cn } from "../utils/cn";

export function TabStrip() {
  const b = useBrowser();
  const { tabs, active, settings } = b;
  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null);
  const drag = useRef<number | null>(null);
  const [fs, setFs] = useState(false);

  const toggleFs = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.().catch(() => b.toast("Полноэкранный режим недоступен"));
    setFs(!document.fullscreenElement);
  };

  const menuItems = (id: string): MenuEntry[] => {
    const t = tabs.find((x) => x.id === id)!;
    const i = tabs.indexOf(t);
    return [
      { label: "Новая вкладка справа", icon: <Plus size={14} />, onClick: () => { b.activate(id); b.newTab(); } },
      { sep: true },
      { label: "Обновить", icon: <RotateCw size={14} />, onClick: () => b.reload(id) },
      { label: "Дублировать", icon: <Copy size={14} />, onClick: () => b.duplicate(id) },
      { label: t.pinned ? "Открепить" : "Закрепить", icon: t.pinned ? <PinOff size={14} /> : <Pin size={14} />, onClick: () => b.togglePin(id) },
      { label: t.muted ? "Включить звук" : "Отключить звук", icon: t.muted ? <Volume2 size={14} /> : <VolumeX size={14} />, onClick: () => b.toggleMute(id) },
      { sep: true },
      { label: "Закрыть вкладку", icon: <X size={14} />, kbd: "Ctrl+W", onClick: () => b.closeTab(id) },
      { label: "Закрыть остальные", disabled: tabs.length < 2, onClick: () => b.closeOthers(id) },
      { label: "Закрыть вкладки справа", disabled: i === tabs.length - 1, onClick: () => b.closeRight(id) },
      { sep: true },
      { label: "Открыть закрытую вкладку", icon: <History size={14} />, kbd: "Ctrl+Shift+T", disabled: !b.canRestore, onClick: b.restoreTab },
    ];
  };

  return (
    <div
      className="no-select flex items-stretch h-[42px] flex-none relative"
      style={{ background: "var(--strip-bg)" }}
      onWheel={(e) => { if (settings.wheelSwitch) b.cycle(e.deltaY > 0 ? 1 : -1); }}
    >
      <div className="flex items-center gap-2 pl-3 pr-2 flex-none">
        <Logo size={20} />
      </div>

      <div className="flex items-end flex-1 min-w-0 pt-[7px] pr-2 gap-0">
        {tabs.map((t, i) => {
          const url = t.stack[t.pos];
          const isActive = t.id === active.id;
          return (
            <div key={t.id} className={cn("flex items-center min-w-0", t.pinned ? "flex-none" : "flex-1 basis-0 max-w-[240px]")}>
              <div
                draggable
                onDragStart={(e) => { drag.current = i; e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", t.id); }}
                onDragOver={(e) => {
                  e.preventDefault();
                  const from = drag.current;
                  if (from !== null && from !== i) { b.moveTab(from, i); drag.current = i; }
                }}
                onDragEnd={() => { drag.current = null; }}
                onMouseDown={(e) => { if (e.button === 0) b.activate(t.id); if (e.button === 1) { e.preventDefault(); b.closeTab(t.id); } }}
                onDoubleClick={() => settings.closeOnDblClick && b.closeTab(t.id)}
                onContextMenu={(e) => { e.preventDefault(); setMenu({ x: e.clientX, y: e.clientY, id: t.id }); }}
                title={t.title}
                className={cn(
                  "tab animate-tab-in group flex items-center gap-2 h-[35px] rounded-t-[10px] px-2.5 cursor-default w-full min-w-0",
                  isActive && "active", t.pinned && "!w-[38px] justify-center px-0", t.sleeping && !isActive && "opacity-55",
                )}
              >
                <span className="relative flex-none flex items-center justify-center w-4 h-4">
                  {t.loading ? (
                    <span className="w-[14px] h-[14px] rounded-full border-2 animate-spin-slow" style={{ borderColor: "var(--glass-bright)", borderTopColor: "var(--accent)" }} />
                  ) : t.sleeping ? (
                    <Moon size={14} className="t2" />
                  ) : t.incognito ? (
                    <EyeOff size={14} style={{ color: "#a985ff" }} />
                  ) : (
                    <PageIcon url={url} />
                  )}
                </span>
                {!t.pinned && (
                  <>
                    <span className={cn("flex-1 min-w-0 truncate text-[12.5px]", isActive ? "t1 font-medium" : "t2")}>{t.title}</span>
                    {t.muted && <VolumeX size={13} className="t2 flex-none" />}
                    <button
                      className="tab-close ibtn !w-[18px] !h-[18px] !rounded-full flex-none"
                      aria-label="Закрыть вкладку"
                      onMouseDown={(e) => e.stopPropagation()}
                      onClick={(e) => { e.stopPropagation(); b.closeTab(t.id); }}
                    >
                      <X size={12} />
                    </button>
                  </>
                )}
              </div>
              {!isActive && <span className="tab-sep ml-[-1px]" />}
            </div>
          );
        })}
        <button
          className="ibtn !w-[28px] !h-[28px] mb-[3px] ml-1.5 flex-none"
          onClick={() => b.newTab()} aria-label="Новая вкладка" title="Новая вкладка (Ctrl+T)"
        >
          <Plus size={17} />
        </button>
      </div>

      <div className="flex items-stretch flex-none">
        <button className="winbtn" aria-label="Свернуть" onClick={() => b.toast("Свернуть окно можно только в приложении")}><Minus size={15} /></button>
        <button className="winbtn" aria-label="Развернуть" onClick={toggleFs}>
          {fs ? <Square size={11} /> : <Maximize2 size={12} />}
        </button>
        <button className="winbtn close" aria-label="Закрыть" onClick={() => b.toast("Окно закрывается только в приложении")}><X size={16} /></button>
      </div>

      {menu && <ContextMenu x={menu.x} y={menu.y} items={menuItems(menu.id)} onClose={() => setMenu(null)} />}
    </div>
  );
}
