import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useOutside } from "./ui";

export interface MenuEntry {
  label?: string;
  icon?: ReactNode;
  kbd?: string;
  danger?: boolean;
  disabled?: boolean;
  sep?: boolean;
  onClick?: () => void;
}

export function ContextMenu({
  x, y, items, onClose,
}: { x: number; y: number; items: MenuEntry[]; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x, y });
  useOutside(ref, onClose);
  useLayoutEffect(() => {
    const r = ref.current!.getBoundingClientRect();
    setPos({ x: Math.min(x, innerWidth - r.width - 8), y: Math.min(y, innerHeight - r.height - 8) });
  }, [x, y]);
  return createPortal(
    <div
      ref={ref} className="menu fixed z-[100] no-select" style={{ left: pos.x, top: pos.y, transformOrigin: "top left" }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {items.map((it, i) =>
        it.sep ? (
          <div key={i} className="menu-sep" />
        ) : (
          <button
            key={i} disabled={it.disabled} className={"menu-item" + (it.danger ? " danger" : "")}
            onClick={() => { onClose(); it.onClick?.(); }}
          >
            {it.icon && <span className="w-4 flex-none inline-flex justify-center">{it.icon}</span>}
            <span>{it.label}</span>
            {it.kbd && <span className="kbd">{it.kbd}</span>}
          </button>
        ),
      )}
    </div>,
    document.body,
  );
}
