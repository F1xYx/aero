import { useEffect, useState } from "react";
import { ExternalLink, X } from "lucide-react";
import { useBrowser } from "../store/browser";
import { isInternal } from "../lib/url";
import type { Tab } from "../lib/types";
import { FindBar } from "./FindBar";
import { NewTab } from "../pages/NewTab";
import { SettingsPage } from "../pages/Settings";
import { HistoryPage } from "../pages/History";
import { DownloadsPage } from "../pages/Downloads";
import { BookmarksPage } from "../pages/Bookmarks";
import { PasswordsPage } from "../pages/Passwords";
import { ExtensionsPage } from "../pages/Extensions";

function Frame({ tab, visible }: { tab: Tab; visible: boolean }) {
  const b = useBrowser();
  const url = tab.stack[tab.pos];
  const [hint, setHint] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  // страховка: не держим индикатор загрузки вечно
  useEffect(() => {
    if (!tab.loading) return;
    const t = setTimeout(() => b.markLoaded(tab.id, url), 12000);
    return () => clearTimeout(t);
  }, [tab.loading, tab.reloadKey, url]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setHint(false); setDismissed(false);
    const t = setTimeout(() => setHint(true), 1800);
    return () => clearTimeout(t);
  }, [url, tab.reloadKey]);

  const z = tab.zoom / 100;
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ display: visible ? "block" : "none", background: "#fff" }}>
      <iframe
        key={tab.reloadKey}
        src={url}
        title={tab.title}
        onLoad={() => b.markLoaded(tab.id, url)}
        allow="fullscreen; clipboard-write; autoplay; picture-in-picture; geolocation"
        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-presentation allow-modals"
        referrerPolicy={b.settings.noReferrer || tab.incognito ? "strict-origin" : "unsafe-url"}
        className="border-0 block bg-white"
        style={{ width: `${100 / z}%`, height: `${100 / z}%`, transform: `scale(${z})`, transformOrigin: "0 0" }}
      />
      {visible && hint && !dismissed && !tab.loading && (
        <div
          className="absolute bottom-4 right-4 flex items-center gap-1 pl-3.5 pr-1.5 py-1.5 rounded-full text-[12.5px] animate-pop"
          style={{ background: "var(--glass-strong)", border: "1px solid var(--hairline)", boxShadow: "var(--shadow-2)", color: "var(--text)", transformOrigin: "bottom right" }}
        >
          <span className="t2">Страница пустая?</span>
          <button className="btn !h-7 !px-2.5 primary" onClick={() => window.open(url, "_blank", "noopener")}>
            <ExternalLink size={13} /> Открыть напрямую
          </button>
          <button className="ibtn !w-6 !h-6" onClick={() => setDismissed(true)} aria-label="Скрыть"><X size={13} /></button>
        </div>
      )}
    </div>
  );
}

function Internal({ url }: { url: string }) {
  switch (url) {
    case "aera://settings": return <SettingsPage />;
    case "aera://history": return <HistoryPage />;
    case "aera://downloads": return <DownloadsPage />;
    case "aera://bookmarks": return <BookmarksPage />;
    case "aera://passwords": return <PasswordsPage />;
    case "aera://extensions": return <ExtensionsPage />;
    default: return <NewTab />;
  }
}

export function Viewport() {
  const b = useBrowser();
  const url = b.active.stack[b.active.pos];
  return (
    <div className="relative flex-1 min-h-0" style={{ background: "var(--bg)" }}>
      {b.tabs.map((t) => {
        const u = t.stack[t.pos];
        if (isInternal(u) || t.sleeping) return null;
        return <Frame key={t.id} tab={t} visible={t.id === b.active.id} />;
      })}
      {isInternal(url) && (
        <div
          key={b.active.id + url} className="absolute top-0 left-0 animate-fade"
          style={{ zoom: b.active.zoom / 100, width: `${10000 / b.active.zoom}%`, height: `${10000 / b.active.zoom}%` }}
        >
          <Internal url={url} />
        </div>
      )}
      {b.findOpen && <FindBar />}
    </div>
  );
}
