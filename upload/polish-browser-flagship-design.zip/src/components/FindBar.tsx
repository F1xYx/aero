import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronUp, X } from "lucide-react";
import { useBrowser } from "../store/browser";
import { isInternal } from "../lib/url";

type FindFn = (q: string, cs?: boolean, back?: boolean, wrap?: boolean) => boolean;

export function FindBar() {
  const b = useBrowser();
  const ref = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState("");
  const [miss, setMiss] = useState(false);
  const internal = isInternal(b.active.stack[b.active.pos]);

  useEffect(() => { ref.current?.focus(); ref.current?.select(); }, []);

  const find = (back = false) => {
    if (!q || !internal) return;
    const f = (window as unknown as { find?: FindFn }).find;
    setMiss(f ? !f(q, false, back, true) : true);
  };

  return (
    <div className="absolute right-4 top-3 z-40 menu !p-2 flex items-center gap-1.5 animate-pop" style={{ minWidth: 0 }}>
      <input
        ref={ref} value={q} placeholder="Найти на странице" className="field w-[220px]"
        style={miss ? { borderColor: "var(--danger)" } : undefined}
        onChange={(e) => { setQ(e.target.value); setMiss(false); }}
        onKeyDown={(e) => {
          if (e.key === "Enter") find(e.shiftKey);
          if (e.key === "Escape") b.setFindOpen(false);
        }}
      />
      {!internal && <span className="text-[11px] t3 max-w-[120px] leading-tight">Недоступно для внешних сайтов в веб-режиме</span>}
      <button className="ibtn !w-7 !h-7" onClick={() => find(true)} aria-label="Предыдущее"><ChevronUp size={16} /></button>
      <button className="ibtn !w-7 !h-7" onClick={() => find(false)} aria-label="Следующее"><ChevronDown size={16} /></button>
      <button className="ibtn !w-7 !h-7" onClick={() => b.setFindOpen(false)} aria-label="Закрыть"><X size={15} /></button>
    </div>
  );
}
