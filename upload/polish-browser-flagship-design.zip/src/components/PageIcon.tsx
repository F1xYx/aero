import type { ReactElement } from "react";
import { Clock, Download, KeyRound, Puzzle, Settings, Sparkles, Star } from "lucide-react";
import { isInternal } from "../lib/url";
import { Favicon } from "./ui";

export function PageIcon({ url, size = 16 }: { url: string; size?: number }) {
  if (!isInternal(url)) return <Favicon url={url} size={size} />;
  const p = { size, strokeWidth: 2 };
  const map: Record<string, ReactElement> = {
    "aera://newtab": <Sparkles {...p} style={{ color: "var(--accent)" }} />,
    "aera://settings": <Settings {...p} />,
    "aera://history": <Clock {...p} />,
    "aera://downloads": <Download {...p} />,
    "aera://bookmarks": <Star {...p} />,
    "aera://passwords": <KeyRound {...p} />,
    "aera://extensions": <Puzzle {...p} />,
  };
  return <span className="flex-none inline-flex">{map[url] ?? map["aera://newtab"]}</span>;
}
