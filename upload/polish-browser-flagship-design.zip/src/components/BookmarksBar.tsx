import { useState } from "react";
import { ExternalLink, EyeOff, Star, Trash2, ChevronRight, Plus } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Favicon } from "./ui";
import { ContextMenu } from "./ContextMenu";
import { isInternal, titleFor } from "../lib/url";

export function BookmarksBar() {
  const b = useBrowser();
  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null);
  if (!b.settings.bookmarksBar) return null;
  const cur = b.active.stack[b.active.pos];
  const target = menu ? b.bookmarks.find((m) => m.id === menu.id) : null;

  return (
    <div className="no-select flex items-center h-[32px] px-2.5 gap-0.5 flex-none animate-fade" style={{ background: "var(--toolbar-bg)", borderBottom: "1px solid var(--hairline)" }}>
      <div className="flex items-center gap-0.5 flex-1 min-w-0 overflow-hidden">
        {b.bookmarks.map((m) => (
          <button
            key={m.id} title={m.url}
            className="flex items-center gap-1.5 h-[24px] px-2 rounded-md text-[12.5px] max-w-[170px] flex-none transition-colors hover:bg-[var(--hover-fill)] active:bg-[var(--press-fill)]"
            onClick={() => b.navigate(m.url)}
            onAuxClick={(e) => { if (e.button === 1) b.newTab(m.url, { background: true }); }}
            onContextMenu={(e) => { e.preventDefault(); setMenu({ x: e.clientX, y: e.clientY, id: m.id }); }}
          >
            <Favicon url={m.url} size={14} />
            <span className="truncate">{m.title}</span>
          </button>
        ))}
        {b.bookmarks.length === 0 && <span className="text-[12px] t3 px-2">Нажмите ★ в адресной строке, чтобы добавить закладку</span>}
      </div>
      {!isInternal(cur) && !b.isBookmarked(cur) && (
        <button className="ibtn !w-6 !h-6" title="Добавить текущую страницу" onClick={() => b.addBookmark(titleFor(cur), cur)}><Plus size={14} /></button>
      )}
      <button className="flex items-center gap-0.5 h-6 px-2 rounded-md text-[12px] t2 hover:bg-[var(--hover-fill)]" onClick={() => b.openPage("aera://bookmarks")}>
        <Star size={12} /> Все <ChevronRight size={12} />
      </button>
      {menu && target && (
        <ContextMenu
          x={menu.x} y={menu.y} onClose={() => setMenu(null)}
          items={[
            { label: "Открыть в новой вкладке", icon: <ExternalLink size={14} />, onClick: () => b.newTab(target.url) },
            { label: "Открыть в приватной вкладке", icon: <EyeOff size={14} />, onClick: () => b.newTab(target.url, { incognito: true }) },
            { sep: true },
            { label: "Удалить", icon: <Trash2 size={14} />, danger: true, onClick: () => b.removeBookmark(target.id) },
          ]}
        />
      )}
    </div>
  );
}
