import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Clock, Globe, Lock, Search, Sparkles, Star, TriangleAlert, ZoomIn } from "lucide-react";
import { useBrowser } from "../store/browser";
import {
  ENGINES, INTERNAL_PAGES, POPULAR, hostOf, isInternal, isSecure, normalizeInput, prettyUrl,
} from "../lib/url";
import { Favicon } from "./ui";
import { PageIcon } from "./PageIcon";
import { cn } from "../utils/cn";

interface Sug { key: string; icon: ReactNode; title: string; sub?: string; url: string; tag?: string }

export function Omnibox() {
  const b = useBrowser();
  const { active, settings } = b;
  const url = active.stack[active.pos];
  const inputRef = useRef<HTMLInputElement>(null);
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState("");
  const [sel, setSel] = useState(-1);

  useEffect(() => {
    const f = () => inputRef.current?.focus();
    window.addEventListener("aera:focus-omnibox", f);
    return () => window.removeEventListener("aera:focus-omnibox", f);
  }, []);
  useEffect(() => { inputRef.current?.blur(); }, [active.id]);

  const sugs = useMemo<Sug[]>(() => {
    if (!focused) return [];
    const q = draft.trim().toLowerCase();
    const out: Sug[] = [];
    const seen = new Set<string>();
    const add = (s: Sug) => { if (!seen.has(s.url) && out.length < 8) { seen.add(s.url); out.push(s); } };
    const typed = draft.trim();
    const isEditingCurrent = typed === (url === "aera://newtab" ? "" : url);

    if (!q || isEditingCurrent) {
      if (settings.suggestions) {
        b.history.slice(0, 5).forEach((h) => add({ key: "h" + h.id, icon: <Clock size={15} className="t3" />, title: h.title, sub: hostOf(h.url), url: h.url, tag: "История" }));
        b.bookmarks.slice(0, 3).forEach((m) => add({ key: "b" + m.id, icon: <Star size={15} style={{ color: "#f5a623" }} />, title: m.title, sub: hostOf(m.url), url: m.url, tag: "Закладка" }));
      }
      return out;
    }

    const nav = normalizeInput(typed, settings.engine, settings.httpsOnly);
    const isSearch = nav.startsWith(ENGINES[settings.engine].url.split("%s")[0]);
    add(isSearch
      ? { key: "s", icon: <Search size={15} style={{ color: "var(--accent)" }} />, title: typed, sub: `Искать в ${ENGINES[settings.engine].name}`, url: nav }
      : { key: "u", icon: <Globe size={15} style={{ color: "var(--accent)" }} />, title: typed, sub: "Перейти по адресу", url: nav });

    if (settings.suggestions) {
      Object.entries(INTERNAL_PAGES).forEach(([u, p]) => {
        if (u !== "aera://newtab" && (p.keywords.includes(q) || p.title.toLowerCase().includes(q)))
          add({ key: u, icon: <PageIcon url={u} size={15} />, title: p.title, sub: u, url: u, tag: "Aera" });
      });
      b.bookmarks.filter((m) => m.title.toLowerCase().includes(q) || m.url.toLowerCase().includes(q))
        .forEach((m) => add({ key: "b" + m.id, icon: <Star size={15} style={{ color: "#f5a623" }} />, title: m.title, sub: hostOf(m.url), url: m.url, tag: "Закладка" }));
      b.history.filter((h) => h.title.toLowerCase().includes(q) || h.url.toLowerCase().includes(q))
        .forEach((h) => add({ key: "h" + h.id, icon: <Clock size={15} className="t3" />, title: h.title, sub: hostOf(h.url), url: h.url, tag: "История" }));
      POPULAR.filter((d) => d.startsWith(q) || d.includes("." + q)).slice(0, 2)
        .forEach((d) => add({ key: "p" + d, icon: <Favicon url={"https://" + d} size={15} />, title: d, sub: "Популярный сайт", url: "https://" + d }));
      if (!isSearch) add({ key: "s2", icon: <Search size={15} className="t3" />, title: typed, sub: `Искать в ${ENGINES[settings.engine].name}`, url: ENGINES[settings.engine].url.replace("%s", encodeURIComponent(typed)) });
    }
    return out;
  }, [focused, draft, url, settings.suggestions, settings.engine, settings.httpsOnly, b.history, b.bookmarks]);

  useEffect(() => setSel(-1), [draft]);

  const commit = (target: string | null, newTab = false) => {
    const dest = target ?? normalizeInput(draft, settings.engine, settings.httpsOnly);
    inputRef.current?.blur();
    if (newTab) b.newTab(dest); else b.navigate(dest);
  };

  const secure = isSecure(url);
  const internal = isInternal(url);
  const bookmarked = b.isBookmarked(url);
  const display = focused ? draft : prettyUrl(url);

  return (
    <div className="relative flex-1 max-w-[780px] mx-auto w-full">
      <div className={cn("omni", focused && "focus")}>
        <span className="ml-1.5 flex-none flex items-center justify-center w-4">
          {focused ? <Search size={14} className="t3" />
            : internal ? <PageIcon url={url} size={14} />
            : secure ? <Lock size={13} className="t2" />
            : <TriangleAlert size={14} style={{ color: "var(--warn)" }} />}
        </span>
        <input
          ref={inputRef} value={display} spellCheck={false} autoComplete="off"
          placeholder={`Поиск в ${ENGINES[settings.engine].name} или адрес сайта`}
          onFocus={(e) => { setFocused(true); setDraft(url === "aera://newtab" ? "" : url); requestAnimationFrame(() => e.target.select()); }}
          onBlur={() => setFocused(false)}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, sugs.length - 1)); }
            else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, -1)); }
            else if (e.key === "Enter") { e.preventDefault(); commit(sel >= 0 ? sugs[sel].url : null, e.altKey); }
            else if (e.key === "Escape") { inputRef.current?.blur(); }
          }}
        />
        {!focused && active.zoom !== 100 && (
          <button className="flex items-center gap-1 text-[11px] font-medium px-1.5 h-5 rounded-md t2 hover:bg-[var(--hover-fill)]" onClick={() => b.zoom("reset")} title="Сбросить масштаб">
            <ZoomIn size={12} />{active.zoom}%
          </button>
        )}
        {!internal && (
          <button
            className={cn("ibtn !w-[26px] !h-[26px] flex-none", bookmarked && "!text-[#f5a623]")}
            onClick={() => b.toggleBookmark()} aria-label="В закладки" title="Добавить в закладки (Ctrl+D)"
          >
            <Star size={15} fill={bookmarked ? "currentColor" : "none"} />
          </button>
        )}
        {internal && !focused && <Sparkles size={13} className="t3 mr-1.5" />}
      </div>

      {focused && sugs.length > 0 && (
        <div className="menu absolute left-0 right-0 top-[38px] z-50 !p-1.5" style={{ transformOrigin: "top center" }} onMouseDown={(e) => e.preventDefault()}>
          {!draft.trim() || draft.trim() === url ? <div className="px-2.5 pt-1 pb-1.5 text-[11px] font-semibold uppercase tracking-wider t3">Недавнее</div> : null}
          {sugs.map((s, i) => (
            <button
              key={s.key} className={cn("menu-item !py-2", i === sel && "active")}
              onMouseEnter={() => setSel(i)} onClick={() => commit(s.url)}
            >
              <span className="w-5 flex-none flex justify-center">{s.icon}</span>
              <span className="truncate font-medium">{s.title}</span>
              {s.sub && <span className={cn("truncate text-[12px] min-w-0", i === sel ? "text-white/70" : "t3")}>— {s.sub}</span>}
              {s.tag && <span className="kbd">{s.tag}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
