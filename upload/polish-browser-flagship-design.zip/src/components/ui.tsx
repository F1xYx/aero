import { useEffect, useState, type ReactNode, type RefObject } from "react";
import { colorFor, faviconUrl, hostOf } from "../lib/url";
import { cn } from "../utils/cn";

export function Logo({ size = 64, className }: { size?: number; className?: string }) {
  const id = "lg" + size;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} aria-label="Aera">
      <defs>
        <linearGradient id={id} x1="8" y1="4" x2="56" y2="60" gradientUnits="userSpaceOnUse">
          <stop stopColor="#6fd3ff" />
          <stop offset="0.55" stopColor="#4f7bff" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
        <linearGradient id={id + "s"} x1="0" y1="0" x2="0" y2="64" gradientUnits="userSpaceOnUse">
          <stop stopColor="#fff" stopOpacity="0.55" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="17" fill={`url(#${id})`} />
      <rect x="2" y="2" width="60" height="60" rx="17" fill={`url(#${id}s)`} />
      <path d="M32 15 L46 49 H39.6 L36.6 41.4 H27.4 L24.4 49 H18 Z M29.4 36 H34.6 L32 29 Z" fill="#fff" />
    </svg>
  );
}

export function Favicon({ url, size = 16, className }: { url: string; size?: number; className?: string }) {
  const [bad, setBad] = useState(false);
  const host = hostOf(url);
  useEffect(() => setBad(false), [url]);
  if (!host || bad) {
    return (
      <span
        className={cn("inline-flex items-center justify-center rounded-[5px] text-white font-semibold uppercase flex-none", className)}
        style={{ width: size, height: size, fontSize: size * 0.58, background: colorFor(host || "aera") }}
      >
        {(host || "a")[0]}
      </span>
    );
  }
  return (
    <img
      src={faviconUrl(url, size > 24 ? 128 : 64)}
      width={size} height={size} alt="" draggable={false}
      onError={() => setBad(true)}
      className={cn("rounded-[4px] flex-none object-contain", className)}
    />
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} className="switch" onClick={() => onChange(!checked)} />
  );
}

export function Seg<T extends string | number>({
  value, onChange, options,
}: { value: T; onChange: (v: T) => void; options: { value: T; label: ReactNode }[] }) {
  return (
    <div className="seg">
      {options.map((o) => (
        <button key={String(o.value)} aria-pressed={o.value === value} onClick={() => onChange(o.value)}>{o.label}</button>
      ))}
    </div>
  );
}

export function Row({ title, desc, children, icon }: { title: ReactNode; desc?: ReactNode; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="row">
      {icon && <div className="flex-none t2">{icon}</div>}
      <div className="flex-1 min-w-0">
        <div className="text-[13.5px] font-medium">{title}</div>
        {desc && <div className="text-[12px] t2 mt-0.5 leading-snug">{desc}</div>}
      </div>
      {children && <div className="flex-none flex items-center gap-2">{children}</div>}
    </div>
  );
}

export function useOutside(ref: RefObject<HTMLElement | null>, onOut: () => void, active = true) {
  useEffect(() => {
    if (!active) return;
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) onOut(); };
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") onOut(); };
    document.addEventListener("mousedown", h);
    document.addEventListener("keydown", k);
    return () => { document.removeEventListener("mousedown", h); document.removeEventListener("keydown", k); };
  });
}

export function Empty({ icon, title, desc }: { icon: ReactNode; title: string; desc?: string }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 animate-fade">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 t3" style={{ background: "var(--glass-soft)" }}>{icon}</div>
      <div className="text-[15px] font-semibold">{title}</div>
      {desc && <div className="text-[12.5px] t2 mt-1 max-w-xs">{desc}</div>}
    </div>
  );
}

export function PageShell({ title, subtitle, actions, children }: { title: string; subtitle?: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <div className="h-full overflow-y-auto" style={{ background: "var(--bg)" }}>
      <div className="max-w-[820px] mx-auto px-6 py-10 animate-rise">
        <div className="flex items-end gap-4 mb-6">
          <div className="flex-1 min-w-0">
            <h1 className="text-[28px] font-bold tracking-tight">{title}</h1>
            {subtitle && <p className="t2 text-[13px] mt-1">{subtitle}</p>}
          </div>
          {actions && <div className="flex gap-2">{actions}</div>}
        </div>
        {children}
      </div>
    </div>
  );
}
