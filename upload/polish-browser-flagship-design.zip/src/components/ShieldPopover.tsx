import { Cookie, EyeOff, Lock, ShieldCheck, Ban, Link2Off } from "lucide-react";
import { useBrowser } from "../store/browser";
import { hostOf, isInternal } from "../lib/url";
import { Switch } from "./ui";
import type { Settings } from "../lib/types";

const ITEMS: { key: keyof Settings; title: string; desc: string; icon: typeof Ban }[] = [
  { key: "blockAds", title: "Реклама и трекеры", desc: "Движок EasyList", icon: Ban },
  { key: "httpsOnly", title: "HTTPS-only", desc: "http:// → https://", icon: Lock },
  { key: "dnt", title: "Do Not Track", desc: "Запрет на слежку (DNT: 1)", icon: EyeOff },
  { key: "noReferrer", title: "Скрывать источник", desc: "Только домен в Referer", icon: Link2Off },
  { key: "blockThirdCookies", title: "Сторонние cookie", desc: "Без меток в браузере", icon: Cookie },
];

export function ShieldPopover() {
  const b = useBrowser();
  const url = b.active.stack[b.active.pos];
  const all = ITEMS.every((i) => b.settings[i.key]);
  const toggleAll = () => ITEMS.forEach((i) => b.setSetting(i.key, !all as never));

  return (
    <div className="menu absolute right-0 top-[38px] z-50 w-[320px] !p-0 overflow-hidden">
      <div className="p-4 pb-3 flex items-center gap-3" style={{ background: "linear-gradient(135deg, var(--accent-soft), transparent)" }}>
        <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white flex-none" style={{ background: "var(--accent)" }}>
          <ShieldCheck size={24} />
        </div>
        <div className="min-w-0">
          <div className="font-semibold text-[14px]">{all ? "Защита включена" : "Защита частично"}</div>
          <div className="text-[12px] t2 truncate">{isInternal(url) ? "Страница Aera" : hostOf(url)}</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 px-4 pb-3">
        <Stat value={b.active.blocked} label="на странице" />
        <Stat value={b.blocked} label="за сессию" />
      </div>

      <div className="px-2 pb-1">
        {ITEMS.map((it) => (
          <div key={it.key} className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-[var(--hover-fill)]">
            <it.icon size={16} className="t2 flex-none" />
            <div className="flex-1 min-w-0">
              <div className="text-[13px] font-medium">{it.title}</div>
              <div className="text-[11.5px] t3">{it.desc}</div>
            </div>
            <Switch checked={b.settings[it.key] as boolean} onChange={(v) => b.setSetting(it.key, v as never)} label={it.title} />
          </div>
        ))}
      </div>

      <div className="p-3 pt-2">
        <button className="btn primary w-full" onClick={toggleAll}>{all ? "Отключить всё" : "Защитить всё"}</button>
      </div>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-xl px-3 py-2" style={{ background: "var(--glass-soft)" }}>
      <div className="text-[22px] font-bold tabular-nums leading-tight">{value}</div>
      <div className="text-[11.5px] t2">{label}</div>
    </div>
  );
}
