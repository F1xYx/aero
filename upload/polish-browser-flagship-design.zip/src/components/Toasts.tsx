import { CheckCircle2, Info, TriangleAlert } from "lucide-react";
import { useBrowser } from "../store/browser";

export function Toasts() {
  const { toasts } = useBrowser();
  return (
    <div className="fixed bottom-6 left-1/2 z-[200] flex flex-col items-center gap-2 pointer-events-none" style={{ transform: "translateX(-50%)" }}>
      {toasts.map((t) => (
        <div
          key={t.id}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-medium animate-pop"
          style={{ background: "var(--glass-strong)", border: "1px solid var(--hairline)", boxShadow: "var(--shadow-2)", transformOrigin: "bottom center" }}
        >
          {t.kind === "ok" ? <CheckCircle2 size={16} style={{ color: "var(--ok)" }} /> : t.kind === "warn" ? <TriangleAlert size={16} style={{ color: "var(--warn)" }} /> : <Info size={16} style={{ color: "var(--accent)" }} />}
          {t.text}
        </div>
      ))}
    </div>
  );
}
