import {
  Clock, Download, EyeOff, KeyRound, Link2, Minus, Plus, Puzzle, Search, Settings, Sparkles, Star, History, Info, Printer,
} from "lucide-react";
import { useBrowser } from "../store/browser";
import { isInternal } from "../lib/url";

export function MainMenu({ close }: { close: () => void }) {
  const b = useBrowser();
  const url = b.active.stack[b.active.pos];
  const Item = ({ icon, label, kbd, onClick, disabled }: { icon: React.ReactNode; label: string; kbd?: string; onClick: () => void; disabled?: boolean }) => (
    <button className="menu-item" disabled={disabled} onClick={() => { close(); onClick(); }}>
      <span className="w-4 flex-none inline-flex justify-center">{icon}</span>
      <span>{label}</span>
      {kbd && <span className="kbd">{kbd}</span>}
    </button>
  );

  return (
    <div className="menu absolute right-0 top-[38px] z-50 w-[280px]">
      <Item icon={<Plus size={15} />} label="Новая вкладка" kbd="Ctrl+T" onClick={() => b.newTab()} />
      <Item icon={<EyeOff size={15} />} label="Приватная вкладка" kbd="Ctrl+Shift+N" onClick={() => b.newTab("aera://newtab", { incognito: true })} />
      <Item icon={<History size={15} />} label="Открыть закрытую" kbd="Ctrl+Shift+T" disabled={!b.canRestore} onClick={b.restoreTab} />
      <div className="menu-sep" />
      <Item icon={<Star size={15} />} label="Закладки" onClick={() => b.openPage("aera://bookmarks")} />
      <Item icon={<Clock size={15} />} label="История" kbd="Ctrl+Y" onClick={() => b.openPage("aera://history")} />
      <Item icon={<Download size={15} />} label="Загрузки" kbd="Ctrl+J" onClick={() => b.openPage("aera://downloads")} />
      <Item icon={<KeyRound size={15} />} label="Пароли" kbd="Ctrl+Shift+P" onClick={() => b.openPage("aera://passwords")} />
      <Item icon={<Puzzle size={15} />} label="Расширения" kbd="Ctrl+Shift+E" onClick={() => b.openPage("aera://extensions")} />
      <div className="menu-sep" />
      <div className="flex items-center gap-2 px-2.5 py-1">
        <span className="text-[13px]">Масштаб</span>
        <div className="ml-auto flex items-center gap-1 rounded-lg" style={{ background: "var(--glass-soft)" }}>
          <button className="ibtn !w-7 !h-7" onClick={() => b.zoom(-10)} aria-label="Уменьшить"><Minus size={14} /></button>
          <button className="text-[12px] font-medium w-11 text-center tabular-nums" onClick={() => b.zoom("reset")} title="Сбросить">{b.active.zoom}%</button>
          <button className="ibtn !w-7 !h-7" onClick={() => b.zoom(10)} aria-label="Увеличить"><Plus size={14} /></button>
        </div>
      </div>
      <Item icon={<Search size={15} />} label="Найти на странице" kbd="Ctrl+F" onClick={() => b.setFindOpen(true)} />
      <Item icon={<Link2 size={15} />} label="Копировать адрес" disabled={isInternal(url)} onClick={() => { navigator.clipboard?.writeText(url); b.toast("Адрес скопирован", "ok"); }} />
      <Item icon={<Printer size={15} />} label="Печать…" kbd="Ctrl+P" onClick={() => window.print()} />
      <div className="menu-sep" />
      <Item icon={<Settings size={15} />} label="Настройки" kbd="Ctrl+," onClick={() => b.openPage("aera://settings")} />
      <Item icon={<Sparkles size={15} />} label="Что нового в Aera" onClick={() => b.newTab("https://github.com/F1xYx/aera")} />
      <Item icon={<Info size={15} />} label="О программе" onClick={() => { b.openPage("aera://settings"); setTimeout(() => window.dispatchEvent(new CustomEvent("aera:settings-section", { detail: "about" })), 60); }} />
    </div>
  );
}
