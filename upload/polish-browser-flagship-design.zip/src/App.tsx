import { useEffect } from "react";
import { BrowserProvider, useBrowser } from "./store/browser";
import { TabStrip } from "./components/TabStrip";
import { Toolbar } from "./components/Toolbar";
import { BookmarksBar } from "./components/BookmarksBar";
import { Viewport } from "./components/Viewport";
import { Toasts } from "./components/Toasts";

function Shell() {
  const b = useBrowser();
  const { settings } = b;

  // горячие клавиши
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();
      const stop = () => { e.preventDefault(); e.stopPropagation(); };
      const inField = (e.target as HTMLElement)?.tagName === "TEXTAREA";

      if (e.altKey && !mod) {
        if (k === "t") return stop(), b.newTab();
        if (k === "w") return stop(), b.closeTab(b.active.id);
        if (k === "arrowleft") return stop(), b.go(-1);
        if (k === "arrowright") return stop(), b.go(1);
        if (k === "home") return stop(), b.goHome();
        return;
      }
      if (k === "f5") return stop(), b.reload();
      if (k === "escape") { if (b.findOpen) b.setFindOpen(false); return; }
      if (!mod) return;

      if (e.shiftKey) {
        if (k === "t") return stop(), b.restoreTab();
        if (k === "n") return stop(), void b.newTab("aera://newtab", { incognito: true });
        if (k === "b") return stop(), b.setSetting("bookmarksBar", !settings.bookmarksBar);
        if (k === "e") return stop(), b.openPage("aera://extensions");
        if (k === "p") return stop(), b.openPage("aera://passwords");
        return;
      }
      switch (k) {
        case "t": return stop(), void b.newTab();
        case "w": return stop(), b.closeTab(b.active.id);
        case "l": return stop(), b.focusOmnibox();
        case "f": if (inField) return; return stop(), b.setFindOpen(true);
        case "d": return stop(), b.toggleBookmark();
        case "j": return stop(), b.openPage("aera://downloads");
        case "y": return stop(), b.openPage("aera://history");
        case ",": return stop(), b.openPage("aera://settings");
        case "r": return stop(), b.reload();
        case "tab": return stop(), b.cycle(1);
        case "=": case "+": return stop(), b.zoom(10);
        case "-": return stop(), b.zoom(-10);
        case "0": return stop(), b.zoom("reset");
        default:
          if (/^[1-9]$/.test(k)) return stop(), b.activateIndex(Number(k) - 1);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  });

  // заголовок документа = заголовок вкладки
  useEffect(() => { document.title = `${b.active.title} — Aera`; }, [b.active.title]);

  const z = settings.uiScale / 100;
  return (
    <div
      className="flex flex-col"
      style={{ zoom: z, width: `${100 / z}vw`, height: `${100 / z}vh`, background: "var(--bg)" }}
    >
      <TabStrip />
      <Toolbar />
      <BookmarksBar />
      <Viewport />
      <Toasts />
    </div>
  );
}

export default function App() {
  return (
    <BrowserProvider>
      <Shell />
    </BrowserProvider>
  );
}
