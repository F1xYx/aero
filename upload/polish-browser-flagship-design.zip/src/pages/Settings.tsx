import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Check, Palette, Rocket, Gauge, PanelTop, ShieldCheck, Lock, Keyboard, Info, ImagePlus, GitBranch, RotateCcw, Trash2,
} from "lucide-react";
import { useBrowser } from "../store/browser";
import { Logo, Row, Seg, Switch } from "../components/ui";
import { ENGINES } from "../lib/url";
import { WALLPAPERS } from "../lib/wallpapers";
import type { Accent, EngineId } from "../lib/types";
import { cn } from "../utils/cn";

const SECTIONS = [
  { id: "appearance", label: "Внешний вид", icon: Palette },
  { id: "startup", label: "Запуск и поиск", icon: Rocket },
  { id: "performance", label: "Производительность", icon: Gauge },
  { id: "tabs", label: "Вкладки", icon: PanelTop },
  { id: "protection", label: "Защита", icon: ShieldCheck },
  { id: "privacy", label: "Приватность", icon: Lock },
  { id: "shortcuts", label: "Горячие клавиши", icon: Keyboard },
  { id: "about", label: "О программе", icon: Info },
] as const;

const ACCENTS: { id: Accent; color: string; name: string }[] = [
  { id: "default", color: "#007aff", name: "Синий" },
  { id: "sunset", color: "#f07422", name: "Закат" },
  { id: "sakura", color: "#ef4f8e", name: "Сакура" },
  { id: "mint", color: "#14b87c", name: "Мята" },
  { id: "golden", color: "#d99a1f", name: "Золото" },
  { id: "lavender", color: "#8b5cf6", name: "Лаванда" },
  { id: "crimson", color: "#e0352b", name: "Малина" },
  { id: "graphite", color: "#6e6e73", name: "Графит" },
];

const SHORTCUTS: [string, string][] = [
  ["Ctrl+T / Alt+T", "Новая вкладка"],
  ["Ctrl+W / Alt+W", "Закрыть вкладку"],
  ["Ctrl+Shift+T", "Открыть закрытую"],
  ["Ctrl+Shift+N", "Приватная вкладка"],
  ["Ctrl+Tab", "Следующая вкладка"],
  ["Ctrl+L", "Адресная строка"],
  ["Ctrl+F", "Найти на странице"],
  ["Ctrl+D", "В закладки"],
  ["Ctrl+J", "Загрузки"],
  ["Ctrl+Y", "История"],
  ["Ctrl+Shift+E", "Магазин расширений"],
  ["Ctrl+Shift+P", "Менеджер паролей"],
  ["Ctrl+Shift+B", "Панель закладок"],
  ["Ctrl+,", "Настройки"],
  ["Ctrl+1…9", "К вкладке по номеру"],
  ["Ctrl + / − / 0", "Масштаб страницы"],
  ["Alt+←  /  Alt+→", "Назад / вперёд"],
  ["Alt+Home", "Домой"],
  ["F5 / Ctrl+R", "Обновить"],
  ["Esc", "Закрыть панель"],
];

function Group({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="mb-7">
      {title && <h3 className="text-[12px] font-semibold uppercase tracking-wider t3 mb-2 px-1">{title}</h3>}
      <div className="card overflow-hidden" style={{ boxShadow: "var(--shadow-1)" }}>{children}</div>
    </section>
  );
}

export function SettingsPage() {
  const b = useBrowser();
  const s = b.settings;
  const [sec, setSec] = useState<string>("appearance");
  const scroller = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const h = (e: Event) => setSec((e as CustomEvent).detail);
    window.addEventListener("aera:settings-section", h);
    return () => window.removeEventListener("aera:settings-section", h);
  }, []);
  useEffect(() => { scroller.current?.scrollTo({ top: 0 }); }, [sec]);

  const protectAll = () => {
    const on = !(s.blockAds && s.httpsOnly && s.dnt && s.noReferrer && s.blockThirdCookies);
    (["blockAds", "httpsOnly", "dnt", "noReferrer", "blockThirdCookies"] as const).forEach((k) => b.setSetting(k, on));
    b.toast(on ? "Защита включена" : "Защита отключена", on ? "ok" : "info");
  };

  const upload = (f?: File) => {
    if (!f) return;
    if (f.size > 3_500_000) { b.toast("Файл слишком большой (до 3.5 МБ)", "warn"); return; }
    const r = new FileReader();
    r.onload = () => { b.setSetting("customWallpaper", String(r.result)); b.setSetting("wallpaper", "custom"); };
    r.readAsDataURL(f);
  };

  const clearAll = () => {
    b.clearHistory();
    b.clearDownloads();
    b.toast("Данные браузера очищены", "ok");
  };

  return (
    <div className="h-full flex" style={{ background: "var(--bg)" }}>
      <nav className="w-[230px] flex-none p-4 pt-8 overflow-y-auto no-select hidden md:block" style={{ borderRight: "1px solid var(--hairline)" }}>
        <h1 className="text-[22px] font-bold tracking-tight px-3 mb-4">Настройки</h1>
        {SECTIONS.map((x) => (
          <button
            key={x.id} onClick={() => setSec(x.id)}
            className={cn("flex items-center gap-2.5 w-full h-9 px-3 rounded-[10px] text-[13.5px] mb-0.5 transition-colors", sec === x.id ? "text-white font-medium" : "t1 hover:bg-[var(--hover-fill)]")}
            style={sec === x.id ? { background: "var(--accent)" } : undefined}
          >
            <x.icon size={16} />{x.label}
          </button>
        ))}
      </nav>

      <div ref={scroller} className="flex-1 overflow-y-auto">
        <div key={sec} className="max-w-[720px] mx-auto px-6 py-8 animate-rise">
          <div className="md:hidden mb-4"><Seg value={sec} onChange={setSec} options={SECTIONS.slice(0, 4).map((x) => ({ value: x.id, label: x.label }))} /></div>
          <h2 className="text-[26px] font-bold tracking-tight mb-6">{SECTIONS.find((x) => x.id === sec)?.label}</h2>

          {sec === "appearance" && (<>
            <Group>
              <Row title="Тема интерфейса" desc="Тёмная, светлая или как в системе">
                <Seg value={s.theme} onChange={(v) => b.setSetting("theme", v)} options={[{ value: "system", label: "Система" }, { value: "light", label: "Светлая" }, { value: "dark", label: "Тёмная" }]} />
              </Row>
              <Row title="Акцентный цвет" desc="Кнопки, переключатели и ссылки">
                <div className="flex gap-2 flex-wrap justify-end max-w-[260px]">
                  {ACCENTS.map((a) => (
                    <button
                      key={a.id} title={a.name} onClick={() => b.setSetting("accent", a.id)} aria-label={a.name}
                      className="w-[22px] h-[22px] rounded-full flex items-center justify-center text-white transition-transform hover:scale-125"
                      style={{ background: a.color, boxShadow: s.accent === a.id ? `0 0 0 2px var(--card), 0 0 0 4px ${a.color}` : undefined }}
                    >{s.accent === a.id && <Check size={12} strokeWidth={3} />}</button>
                  ))}
                </div>
              </Row>
              <Row title="Стекло (Liquid Glass)" desc="Полупрозрачные панели и виджеты"><Switch checked={s.glass} onChange={(v) => b.setSetting("glass", v)} label="Стекло" /></Row>
              <Row title="Анимации" desc="Плавные переходы интерфейса"><Switch checked={s.animations} onChange={(v) => b.setSetting("animations", v)} label="Анимации" /></Row>
            </Group>
            <Group title="Обои — фон начальной страницы">
              <div className="p-4 grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))" }}>
                {WALLPAPERS.map((w) => (
                  <button key={w.id} onClick={() => b.setSetting("wallpaper", w.id)} className="group text-left">
                    <div
                      className="h-[72px] rounded-xl flex items-center justify-center text-white transition-transform group-hover:scale-[1.04]"
                      style={{ background: w.css, boxShadow: s.wallpaper === w.id ? "0 0 0 2px var(--card), 0 0 0 4px var(--accent)" : "inset 0 0 0 1px rgba(128,128,128,0.25)" }}
                    >{s.wallpaper === w.id && <Check size={20} />}</div>
                    <div className="text-[12px] t2 mt-1.5 px-0.5">{w.name}</div>
                  </button>
                ))}
                <button onClick={() => fileRef.current?.click()} className="group text-left">
                  <div
                    className="h-[72px] rounded-xl flex items-center justify-center t2 transition-transform group-hover:scale-[1.04]"
                    style={{ background: s.customWallpaper ? `center / cover url(${s.customWallpaper})` : "var(--glass-soft)", boxShadow: s.wallpaper === "custom" ? "0 0 0 2px var(--card), 0 0 0 4px var(--accent)" : "inset 0 0 0 1px rgba(128,128,128,0.25)" }}
                  ><ImagePlus size={22} /></div>
                  <div className="text-[12px] t2 mt-1.5 px-0.5">Своё фото</div>
                </button>
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => upload(e.target.files?.[0])} />
              </div>
            </Group>
            <Group>
              <Row title="Масштаб интерфейса" desc="Размер панелей и вкладок">
                <Seg value={s.uiScale} onChange={(v) => b.setSetting("uiScale", v)} options={[90, 100, 110, 125].map((v) => ({ value: v, label: v + "%" }))} />
              </Row>
              <Row title="Панель закладок" desc="Строка под адресной строкой (Ctrl+Shift+B)"><Switch checked={s.bookmarksBar} onChange={(v) => b.setSetting("bookmarksBar", v)} label="Панель закладок" /></Row>
            </Group>
          </>)}

          {sec === "startup" && (<>
            <Group title="Запуск и главная">
              <Row title="При запуске" desc="Открыть новую вкладку или восстановить сессию">
                <Seg value={s.startup} onChange={(v) => b.setSetting("startup", v)} options={[{ value: "newtab", label: "Новая вкладка" }, { value: "restore", label: "Восстановить" }]} />
              </Row>
              <Row title="Домашняя страница" desc="Кнопка «Домой»; пусто — начальная страница">
                <input className="field w-[220px]" placeholder="https://…" value={s.homepage} onChange={(e) => b.setSetting("homepage", e.target.value)} />
              </Row>
            </Group>
            <Group title="Поиск">
              <Row title="Поисковая система" desc="Адресная строка и новая вкладка">
                <select className="field !pr-6 cursor-pointer" value={s.engine} onChange={(e) => b.setSetting("engine", e.target.value as EngineId)}>
                  {(Object.keys(ENGINES) as EngineId[]).map((id) => <option key={id} value={id}>{ENGINES[id].name}</option>)}
                </select>
              </Row>
              <Row title="Подсказки адресной строки" desc="История и закладки при вводе"><Switch checked={s.suggestions} onChange={(v) => b.setSetting("suggestions", v)} label="Подсказки" /></Row>
            </Group>
          </>)}

          {sec === "performance" && (
            <Group>
              <Row title="Масштаб страниц по умолчанию" desc="Применяется к новым вкладкам">
                <Seg value={s.defaultZoom} onChange={(v) => b.setSetting("defaultZoom", v)} options={[90, 100, 110, 125, 150].map((v) => ({ value: v, label: v + "%" }))} />
              </Row>
              <Row title="Усыплять неактивные вкладки" desc="Через 2 минуты вкладка замораживается и выгружается из памяти"><Switch checked={s.sleepTabs} onChange={(v) => b.setSetting("sleepTabs", v)} label="Усыплять вкладки" /></Row>
            </Group>
          )}

          {sec === "tabs" && (
            <Group>
              <Row title="Новая вкладка после текущей" desc="Иначе — в конце панели вкладок"><Switch checked={s.newTabAfterCurrent} onChange={(v) => b.setSetting("newTabAfterCurrent", v)} label="После текущей" /></Row>
              <Row title="Закрывать вкладку двойным кликом" desc="Двойной клик по вкладке закрывает её"><Switch checked={s.closeOnDblClick} onChange={(v) => b.setSetting("closeOnDblClick", v)} label="Двойной клик" /></Row>
              <Row title="Переключение вкладок колесом" desc="Колесо над панелью вкладок листает вкладки"><Switch checked={s.wheelSwitch} onChange={(v) => b.setSetting("wheelSwitch", v)} label="Колесо" /></Row>
            </Group>
          )}

          {sec === "protection" && (<>
            <div className="rounded-2xl p-5 mb-7 flex items-center gap-4 text-white" style={{ background: "linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent) 55%, #000))", boxShadow: "var(--shadow-1)" }}>
              <ShieldCheck size={36} className="flex-none" />
              <div className="flex-1 min-w-0">
                <div className="text-[16px] font-semibold">Защитить всё</div>
                <div className="text-[12.5px] opacity-85">Одним кликом: блокировка рекламы, HTTPS-only, DNT, сторонние cookie</div>
              </div>
              <button className="btn !bg-white/20 !text-white hover:!bg-white/30" onClick={protectAll}>Переключить</button>
            </div>
            <Group>
              <Row title="Блокировать рекламу и трекеры" desc="Движок EasyList: домены, подстроки и регулярные выражения"><Switch checked={s.blockAds} onChange={(v) => b.setSetting("blockAds", v)} label="Реклама" /></Row>
              <Row title="HTTPS-only" desc="Сайты с http:// автоматически открываются по безопасному https://"><Switch checked={s.httpsOnly} onChange={(v) => b.setSetting("httpsOnly", v)} label="HTTPS-only" /></Row>
              <Row title="Do Not Track" desc="Сайтам отправляется запрет на слежку (DNT: 1)"><Switch checked={s.dnt} onChange={(v) => b.setSetting("dnt", v)} label="DNT" /></Row>
              <Row title="Не утекать адрес источника" desc="Сторонние сайты видят только домен, с которого вы пришли"><Switch checked={s.noReferrer} onChange={(v) => b.setSetting("noReferrer", v)} label="Referrer" /></Row>
              <Row title="Блокировать сторонние cookie" desc="Сторонние сайты не смогут оставлять метки в браузере"><Switch checked={s.blockThirdCookies} onChange={(v) => b.setSetting("blockThirdCookies", v)} label="Cookie" /></Row>
            </Group>
            <Group>
              <Row title="Заблокировано за сессию" desc="Демонстрационный счётчик веб-версии"><span className="text-[22px] font-bold tabular-nums">{b.blocked}</span></Row>
            </Group>
          </>)}

          {sec === "privacy" && (<>
            <Group>
              <Row title="Сохранять историю" desc="Используется для подсказок и плиток"><Switch checked={s.saveHistory} onChange={(v) => b.setSetting("saveHistory", v)} label="История" /></Row>
              <Row title="Спрашивать, куда сохранять" desc="Диалог выбора папки при каждой загрузке"><Switch checked={s.askDownload} onChange={(v) => b.setSetting("askDownload", v)} label="Спрашивать" /></Row>
              <Row title="Очистить данные браузера" desc="История и список загрузок"><button className="btn danger" onClick={clearAll}><Trash2 size={14} /> Очистить</button></Row>
            </Group>
            <Group>
              <Row title="Сохранённые пароли" desc="Шифрование Windows (DPAPI) в приложении"><button className="btn" onClick={() => b.openPage("aera://passwords")}>Открыть</button></Row>
            </Group>
          </>)}

          {sec === "shortcuts" && (
            <Group>
              {SHORTCUTS.map(([k, d]) => (
                <div key={k} className="row !py-2.5">
                  <span className="flex-1 text-[13.5px]">{d}</span>
                  <span className="flex gap-1">{k.split(/\s*\/\s*/).map((part, i) => (
                    <kbd key={i} className="px-2 py-0.5 rounded-md text-[11.5px] font-medium" style={{ background: "var(--glass-soft)", border: "1px solid var(--hairline)", fontFamily: "inherit" }}>{part}</kbd>
                  ))}</span>
                </div>
              ))}
            </Group>
          )}

          {sec === "about" && (<>
            <div className="card p-8 flex flex-col items-center text-center mb-7" style={{ boxShadow: "var(--shadow-1)" }}>
              <Logo size={88} className="animate-pop" />
              <div className="text-[26px] font-bold mt-4 tracking-tight">Aera</div>
              <div className="t2 text-[13px] mt-1">Версия 2.2.0 · Chromium</div>
              <p className="t2 text-[13px] mt-4 max-w-md leading-relaxed">Быстрый браузер с интерфейсом в стиле Safari, встроенным блокировщиком рекламы, менеджером паролей и магазином расширений.</p>
              <div className="flex gap-2 mt-5">
                <button className="btn primary" onClick={() => b.newTab("https://github.com/F1xYx/aera")}><GitBranch size={14} /> GitHub</button>
                <button className="btn" onClick={b.resetSettings}><RotateCcw size={14} /> Сбросить настройки</button>
              </div>
            </div>
          </>)}
        </div>
      </div>
    </div>
  );
}
