import { useState } from "react";
import { ExternalLink, Plus, Search, Star, Trash2 } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Empty, Favicon, PageShell } from "../components/ui";
import { hostOf, normalizeInput } from "../lib/url";

export function BookmarksPage() {
  const b = useBrowser();
  const [q, setQ] = useState("");
  const [adding, setAdding] = useState(false);
  const [t, setT] = useState("");
  const [u, setU] = useState("");
  const list = b.bookmarks.filter((m) => !q || m.title.toLowerCase().includes(q.toLowerCase()) || m.url.toLowerCase().includes(q.toLowerCase()));

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!u.trim()) return;
    const url = normalizeInput(u, "duckduckgo", false);
    b.addBookmark(t.trim() || hostOf(url), url);
    setT(""); setU(""); setAdding(false);
  };

  return (
    <PageShell
      title="Закладки" subtitle={`${b.bookmarks.length} сохранено · панель закладок: Ctrl+Shift+B`}
      actions={<button className="btn primary" onClick={() => setAdding(!adding)}><Plus size={14} /> Добавить</button>}
    >
      {adding && (
        <form onSubmit={add} className="card p-4 mb-5 flex gap-2 flex-wrap animate-pop" style={{ transformOrigin: "top" }}>
          <input autoFocus className="field flex-1 min-w-[200px]" placeholder="Адрес" value={u} onChange={(e) => setU(e.target.value)} />
          <input className="field flex-1 min-w-[160px]" placeholder="Название" value={t} onChange={(e) => setT(e.target.value)} />
          <button className="btn primary" type="submit">Сохранить</button>
        </form>
      )}
      <div className="relative mb-5">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 t3" />
        <input className="field w-full !h-9 !pl-9" placeholder="Поиск по закладкам" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {list.length === 0 ? (
        <Empty icon={<Star size={28} />} title="Закладок нет" desc="Нажмите ★ в адресной строке, чтобы сохранить страницу." />
      ) : (
        <div className="card overflow-hidden">
          {list.map((m) => (
            <div key={m.id} className="row group hover:bg-[var(--hover-fill)] transition-colors">
              <Favicon url={m.url} size={20} />
              <button className="flex-1 min-w-0 text-left" onClick={() => b.navigate(m.url)}>
                <div className="text-[13.5px] font-medium truncate">{m.title}</div>
                <div className="text-[12px] t3 truncate">{m.url}</div>
              </button>
              <button className="ibtn opacity-0 group-hover:opacity-100" onClick={() => b.newTab(m.url)} aria-label="В новой вкладке"><ExternalLink size={15} /></button>
              <button className="ibtn opacity-0 group-hover:opacity-100" onClick={() => b.removeBookmark(m.id)} aria-label="Удалить"><Trash2 size={15} /></button>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
