import { Download, FileText, Trash2, X } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Empty, PageShell } from "../components/ui";
import { fmtSize, timeAgo } from "../lib/url";

export function DownloadsPage() {
  const b = useBrowser();
  const test = () =>
    b.addDownload(
      "aera-test.txt",
      new Blob([`Aera 2.2.0\nТестовая загрузка — ${new Date().toLocaleString("ru-RU")}\n`], { type: "text/plain" }),
    );

  return (
    <PageShell
      title="Загрузки" subtitle="Файлы, скачанные через Aera"
      actions={<>
        <button className="btn" onClick={test}><Download size={14} /> Тестовая загрузка</button>
        <button className="btn danger" disabled={!b.downloads.length} onClick={b.clearDownloads}><Trash2 size={14} /> Очистить</button>
      </>}
    >
      {b.downloads.length === 0 ? (
        <Empty icon={<Download size={28} />} title="Загрузок пока нет" desc="Когда вы скачаете файл, он появится в этом списке." />
      ) : (
        <div className="card overflow-hidden">
          {b.downloads.map((d) => (
            <div key={d.id} className="row group hover:bg-[var(--hover-fill)] transition-colors">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-none" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}><FileText size={20} /></div>
              <div className="flex-1 min-w-0">
                <div className="text-[13.5px] font-medium truncate">{d.name}</div>
                <div className="text-[12px] t2">{fmtSize(d.size)} · {timeAgo(d.time)}</div>
              </div>
              <button className="ibtn opacity-0 group-hover:opacity-100" onClick={() => b.removeDownload(d.id)} aria-label="Удалить из списка"><X size={15} /></button>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
