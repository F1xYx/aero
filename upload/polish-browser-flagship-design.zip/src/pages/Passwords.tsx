import { useState } from "react";
import { Copy, Eye, EyeOff, KeyRound, Plus, ShieldAlert, Trash2 } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Empty, Favicon, PageShell } from "../components/ui";
import { hostOf, normalizeInput } from "../lib/url";

export function PasswordsPage() {
  const b = useBrowser();
  const [adding, setAdding] = useState(false);
  const [site, setSite] = useState("");
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [shown, setShown] = useState<Record<string, boolean>>({});

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!site.trim() || !pass) return;
    b.addPassword({ site: hostOf(normalizeInput(site, "duckduckgo", false)), user, pass });
    setSite(""); setUser(""); setPass(""); setAdding(false);
  };
  const copy = (s: string, what: string) => { navigator.clipboard?.writeText(s); b.toast(`${what} скопирован`, "ok"); };

  return (
    <PageShell
      title="Пароли" subtitle="Менеджер паролей Aera"
      actions={<button className="btn primary" onClick={() => setAdding(!adding)}><Plus size={14} /> Добавить</button>}
    >
      <div className="flex gap-3 p-4 rounded-2xl mb-5 text-[12.5px] leading-relaxed" style={{ background: "var(--accent-soft)" }}>
        <ShieldAlert size={18} className="flex-none mt-0.5" style={{ color: "var(--accent)" }} />
        <div>В приложении пароли шифруются средствами Windows (DPAPI). В веб-версии они хранятся только в localStorage этого браузера — не используйте здесь реальные пароли.</div>
      </div>
      {adding && (
        <form onSubmit={add} className="card p-4 mb-5 grid gap-2 animate-pop sm:grid-cols-3" style={{ transformOrigin: "top" }}>
          <input autoFocus className="field" placeholder="Сайт" value={site} onChange={(e) => setSite(e.target.value)} />
          <input className="field" placeholder="Логин" value={user} onChange={(e) => setUser(e.target.value)} />
          <input className="field" type="password" placeholder="Пароль" value={pass} onChange={(e) => setPass(e.target.value)} />
          <div className="sm:col-span-3 flex justify-end"><button className="btn primary" type="submit">Сохранить</button></div>
        </form>
      )}
      {b.passwords.length === 0 ? (
        <Empty icon={<KeyRound size={28} />} title="Нет сохранённых паролей" desc="Добавьте пароль вручную — он появится здесь." />
      ) : (
        <div className="card overflow-hidden">
          {b.passwords.map((p) => (
            <div key={p.id} className="row group hover:bg-[var(--hover-fill)] transition-colors">
              <Favicon url={"https://" + p.site} size={20} />
              <div className="flex-1 min-w-0">
                <div className="text-[13.5px] font-medium truncate">{p.site}</div>
                <div className="text-[12px] t2 truncate">{p.user || "без логина"}</div>
              </div>
              <code className="text-[12.5px] t2 tabular-nums select-text">{shown[p.id] ? p.pass : "•".repeat(Math.min(p.pass.length, 12))}</code>
              <button className="ibtn" onClick={() => setShown({ ...shown, [p.id]: !shown[p.id] })} aria-label="Показать">{shown[p.id] ? <EyeOff size={15} /> : <Eye size={15} />}</button>
              <button className="ibtn" onClick={() => copy(p.pass, "Пароль")} aria-label="Копировать"><Copy size={15} /></button>
              <button className="ibtn" onClick={() => b.removePassword(p.id)} aria-label="Удалить"><Trash2 size={15} /></button>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
