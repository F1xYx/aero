import { useMemo, useState } from "react";
import { Clock, Search, Trash2, X } from "lucide-react";
import { useBrowser } from "../store/browser";
import { Empty, Favicon, PageShell } from "../components/ui";
import { hostOf } from "../lib/url";

function dayLabel(t: number) {
  const d = new Date(t); const n = new Date();
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(d, n)) return "Сегодня";
  const y = new Date(n); y.setDate(n.getDate() - 1);
  if (same(d, y)) return "Вчера";
  return d.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });
}

export function HistoryPage() {
  const b = useBrowser();
  const [q, setQ] = useState("");
  const groups = useMemo(() => {
    const f = b.history.filter((h) => !q || h.title.toLowerCase().includes(q.toLowerCase()) || h.url.toLowerCase().includes(q.toLowerCase()));
    const m = new Map<string, typeof f>();
    f.forEach((h) => { const k = dayLabel(h.time); m.set(k, [...(m.get(k) ?? []), h]); });
    return [...m.entries()];
  }, [b.history, q]);

  return (
    <PageShell
      title="История" subtitle={b.settings.saveHistory ? `${b.history.length} записей · приватные вкладки не сохраняются` : "Сохранение истории выключено в настройках"}
      actions={<button className="btn danger" disabled={!b.history.length} onClick={b.clearHistory}><Trash2 size={14} /> Очистить</button>}
    >
      <div className="relative mb-5">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 t3" />
        <input className="field w-full !h-9 !pl-9" placeholder="Поиск по истории" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {groups.length === 0 ? (
        <Empty icon={<Clock size={28} />} title={q ? "Ничего не найдено" : "История пуста"} desc={q ? undefined : "Открытые вами сайты появятся здесь."} />
      ) : groups.map(([day, items]) => (
        <section key={day} className="mb-6">
          <h2 className="text-[12px] font-semibold uppercase tracking-wider t3 mb-2 px-1 capitalize">{day}</h2>
          <div className="card overflow-hidden">
            {items.map((h) => (
              <div key={h.id} className="row !py-2.5 group hover:bg-[var(--hover-fill)] transition-colors">
                <span className="text-[12px] t3 tabular-nums w-11 flex-none">{new Date(h.time).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</span>
                <Favicon url={h.url} size={16} />
                <button className="flex-1 min-w-0 text-left" onClick={() => b.navigate(h.url)}>
                  <span className="text-[13.5px] font-medium truncate block">{h.title}</span>
                </button>
                <span className="t3 text-[12px] truncate max-w-[200px] hidden sm:block">{hostOf(h.url)}</span>
                <button className="ibtn !w-7 !h-7 opacity-0 group-hover:opacity-100" onClick={() => b.removeHistory(h.id)} aria-label="Удалить"><X size={14} /></button>
              </div>
            ))}
          </div>
        </section>
      ))}
    </PageShell>
  );
}
