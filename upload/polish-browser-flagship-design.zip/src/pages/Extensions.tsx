import { useState } from "react";
import { Check, Search, Star, Trash2 } from "lucide-react";
import { useBrowser } from "../store/browser";
import { PageShell, Switch } from "../components/ui";

const CATALOG = [
  { id: "ublock", name: "uBlock Origin Lite", desc: "Лёгкий блокировщик рекламы нового поколения", color: "#e0352b", emoji: "🛡", rating: 4.8 },
  { id: "darkreader", name: "Dark Reader", desc: "Тёмная тема для любых сайтов", color: "#2b2b30", emoji: "🌓", rating: 4.7 },
  { id: "bitwarden", name: "Bitwarden", desc: "Бесплатный менеджер паролей с открытым кодом", color: "#175ddc", emoji: "🔐", rating: 4.6 },
  { id: "sponsorblock", name: "SponsorBlock", desc: "Пропуск рекламных вставок на YouTube", color: "#00d400", emoji: "⏭", rating: 4.9 },
  { id: "ryd", name: "Return YouTube Dislike", desc: "Возвращает счётчик дизлайков", color: "#ff3b30", emoji: "👎", rating: 4.5 },
  { id: "vimium", name: "Vimium C", desc: "Управление браузером с клавиатуры", color: "#6d4aff", emoji: "⌨️", rating: 4.6 },
  { id: "translate", name: "Immersive Translate", desc: "Двуязычный перевод страниц", color: "#ea4c89", emoji: "🌐", rating: 4.7 },
  { id: "tabs", name: "OneTab", desc: "Сводит все вкладки в один список и экономит память", color: "#f5a623", emoji: "🗂", rating: 4.4 },
];

export function ExtensionsPage() {
  const b = useBrowser();
  const [q, setQ] = useState("");
  const installed = CATALOG.filter((c) => c.id in b.extensions);
  const list = CATALOG.filter((c) => !q || (c.name + c.desc).toLowerCase().includes(q.toLowerCase()));

  return (
    <PageShell title="Магазин расширений" subtitle="Каталог «Выбор Aera» · расширения Chromium из Chrome Web Store">
      <div className="relative mb-6">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 t3" />
        <input className="field w-full !h-9 !pl-9" placeholder="Поиск расширений" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {installed.length > 0 && (
        <section className="mb-8">
          <h2 className="text-[12px] font-semibold uppercase tracking-wider t3 mb-2 px-1">Установленные</h2>
          <div className="card overflow-hidden">
            {installed.map((e) => (
              <div key={e.id} className="row">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-[18px] flex-none" style={{ background: e.color }}>{e.emoji}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13.5px] font-medium">{e.name}</div>
                  <div className="text-[12px] t2">{b.extensions[e.id] ? "Включено" : "Отключено"}</div>
                </div>
                <Switch checked={b.extensions[e.id]} onChange={() => b.toggleExtension(e.id)} label={e.name} />
                <button className="ibtn" onClick={() => b.removeExtension(e.id)} aria-label="Удалить"><Trash2 size={15} /></button>
              </div>
            ))}
          </div>
        </section>
      )}

      <h2 className="text-[12px] font-semibold uppercase tracking-wider t3 mb-2 px-1">Выбор Aera</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {list.map((e) => {
          const has = e.id in b.extensions;
          return (
            <div key={e.id} className="card p-4 flex gap-3 transition-transform hover:-translate-y-0.5" style={{ boxShadow: "var(--shadow-1)" }}>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-[24px] flex-none" style={{ background: e.color }}>{e.emoji}</div>
              <div className="flex-1 min-w-0 flex flex-col">
                <div className="text-[14px] font-semibold truncate">{e.name}</div>
                <div className="text-[12px] t2 leading-snug mt-0.5 flex-1">{e.desc}</div>
                <div className="flex items-center mt-3">
                  <span className="flex items-center gap-1 text-[12px] t2"><Star size={12} fill="#f5a623" color="#f5a623" />{e.rating}</span>
                  <button className={"btn ml-auto !h-7 " + (has ? "" : "primary")} disabled={has} onClick={() => b.installExtension(e.id)}>
                    {has ? <><Check size={13} /> Установлено</> : "Установить"}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <p className="text-[12px] t3 mt-6 leading-relaxed">В приложении расширения загружаются через <code>session.loadExtension</code> из <code>userData/extensions/&lt;id&gt;</code>. В веб-версии установка демонстрационная.</p>
    </PageShell>
  );
}
