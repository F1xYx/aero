import { useEffect, useRef, useState } from "react";
import {
  Ban, Check, ChevronDown, EyeOff, ImagePlus, Pencil, Plus, Search, ShieldCheck, SlidersHorizontal, StickyNote, X,
} from "lucide-react";
import { useBrowser } from "../store/browser";
import { ENGINES, hostOf, normalizeInput, uid } from "../lib/url";
import { WALLPAPERS, wallpaperCss } from "../lib/wallpapers";
import { Favicon, Logo, Switch, useOutside } from "../components/ui";
import { ContextMenu } from "../components/ContextMenu";
import type { EngineId } from "../lib/types";
import { cn } from "../utils/cn";

function greeting(h: number) {
  if (h < 5) return "Доброй ночи";
  if (h < 12) return "Доброе утро";
  if (h < 18) return "Добрый день";
  return "Добрый вечер";
}

export function NewTab() {
  const b = useBrowser();
  const { settings, widgets, dial, active } = b;
  const [now, setNow] = useState(new Date());
  const [edit, setEdit] = useState(false);
  const [q, setQ] = useState("");
  const [engMenu, setEngMenu] = useState<{ x: number; y: number } | null>(null);
  const [adding, setAdding] = useState<{ id?: string } | null>(null);
  const dragId = useRef<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const incognito = active.incognito;

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => { if (!edit) inputRef.current?.focus(); }, [edit]);

  const bg = incognito
    ? "radial-gradient(800px 500px at 50% 0%, #4b2f8a 0%, transparent 65%), linear-gradient(180deg, #1a1030, #0b0716)"
    : wallpaperCss(settings.wallpaper, settings.customWallpaper);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    b.navigate(normalizeInput(q, settings.engine, settings.httpsOnly));
  };

  const reorder = (overId: string) => {
    const from = dial.findIndex((d) => d.id === dragId.current);
    const to = dial.findIndex((d) => d.id === overId);
    if (from < 0 || to < 0 || from === to) return;
    const n = [...dial];
    const [m] = n.splice(from, 1);
    n.splice(to, 0, m);
    b.setDial(n);
  };

  const time = now.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  const date = now.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="relative h-full overflow-hidden no-select" style={{ background: bg }} onClick={(e) => { if (edit && e.target === e.currentTarget) setEdit(false); }}>
      <div className="absolute inset-0 overflow-y-auto" onClick={(e) => { if (edit && e.target === e.currentTarget) setEdit(false); }}>
        <div className="min-h-full flex flex-col items-center px-6 pt-[7vh] pb-28" onClick={(e) => { if (edit && e.target === e.currentTarget) setEdit(false); }}>
          {/* часы */}
          {incognito ? (
            <div className="text-center nt-text animate-rise mb-2">
              <div className="w-16 h-16 mx-auto rounded-3xl flex items-center justify-center mb-4" style={{ background: "rgba(169,133,255,0.2)", border: "1px solid rgba(169,133,255,0.4)" }}>
                <EyeOff size={30} color="#c9b3ff" />
              </div>
              <h1 className="text-[34px] font-bold tracking-tight">Приватная вкладка</h1>
              <p className="text-[14px] opacity-75 mt-2 max-w-md mx-auto leading-relaxed">
                Aera не сохраняет историю, поисковые запросы и данные сайтов, пока вы в приватных вкладках. Закладки и загрузки останутся.
              </p>
            </div>
          ) : widgets.clock ? (
            <div className="text-center nt-text animate-rise">
              <div className="text-[96px] leading-none font-extralight tracking-tight tabular-nums" style={{ fontFeatureSettings: '"tnum"' }}>{time}</div>
              <div className="text-[17px] font-medium mt-2 capitalize opacity-90">{date}</div>
              <div className="text-[14px] opacity-70 mt-0.5">{greeting(now.getHours())}</div>
            </div>
          ) : (
            <div className="nt-text flex items-center gap-3 animate-rise">
              <Logo size={56} /><span className="text-[44px] font-bold tracking-tight">Aera</span>
            </div>
          )}

          {/* поиск */}
          <form onSubmit={submit} className="w-full max-w-[640px] mt-9 animate-rise" style={{ animationDelay: "60ms" }}>
            <div
              className="flex items-center h-[54px] rounded-full px-2 transition-all focus-within:scale-[1.015]"
              style={{ background: "rgba(255,255,255,0.94)", boxShadow: "0 12px 40px rgba(0,0,0,0.22), 0 0 0 1px rgba(255,255,255,0.4) inset", color: "#1d1d1f" }}
            >
              <button
                type="button" className="flex items-center gap-1 h-9 pl-3 pr-2 rounded-full text-[12.5px] font-semibold hover:bg-black/5 flex-none"
                onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setEngMenu({ x: r.left, y: r.bottom + 6 }); }}
              >
                <Favicon url={"https://" + ENGINES[settings.engine].home} size={16} />
                {ENGINES[settings.engine].name}<ChevronDown size={13} className="opacity-50" />
              </button>
              <input
                ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} spellCheck={false}
                placeholder="Поиск или адрес сайта" className="flex-1 min-w-0 h-full bg-transparent border-0 px-3 text-[16px] placeholder:text-black/35"
              />
              <button type="submit" className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-none transition-transform active:scale-90" style={{ background: "var(--accent)" }} aria-label="Найти">
                <Search size={18} />
              </button>
            </div>
          </form>

          {/* быстрые ссылки */}
          {widgets.dial && !incognito && (
            <div className="mt-12 grid gap-x-3 gap-y-5 justify-center animate-rise" style={{ gridTemplateColumns: "repeat(auto-fill, 92px)", maxWidth: 760, width: "100%", animationDelay: "120ms" }}>
              {dial.map((d) => (
                <div
                  key={d.id}
                  draggable={edit}
                  onDragStart={() => { dragId.current = d.id; }}
                  onDragOver={(e) => { if (edit) { e.preventDefault(); reorder(d.id); } }}
                  onDragEnd={() => { dragId.current = null; }}
                  className={cn("relative flex flex-col items-center gap-2 w-[92px]", edit && "edit-wiggle cursor-grab")}
                >
                  <button
                    className="tile w-[68px] h-[68px] rounded-[20px] flex items-center justify-center"
                    style={{ background: "rgba(255,255,255,0.92)", boxShadow: "0 8px 22px rgba(0,0,0,0.2)" }}
                    onClick={() => (edit ? setAdding({ id: d.id }) : b.navigate(d.url))}
                    onAuxClick={(e) => { if (e.button === 1) b.newTab(d.url, { background: true }); }}
                    aria-label={d.title}
                  >
                    <Favicon url={d.url} size={34} className="!rounded-[8px]" />
                  </button>
                  <span className="nt-text text-[12px] font-medium truncate w-full text-center">{d.title}</span>
                  {edit && (
                    <button
                      className="absolute -top-1.5 left-[6px] w-[22px] h-[22px] rounded-full flex items-center justify-center text-white"
                      style={{ background: "rgba(40,40,46,0.85)", boxShadow: "0 2px 6px rgba(0,0,0,0.3)" }}
                      onClick={() => b.setDial(dial.filter((x) => x.id !== d.id))} aria-label="Удалить"
                    ><X size={13} /></button>
                  )}
                </div>
              ))}
              <div className="flex flex-col items-center gap-2 w-[92px]">
                <button
                  className="tile w-[68px] h-[68px] rounded-[20px] flex items-center justify-center text-white"
                  style={{ background: "rgba(255,255,255,0.18)", border: "1.5px dashed rgba(255,255,255,0.55)" }}
                  onClick={() => setAdding({})} aria-label="Добавить ссылку"
                ><Plus size={26} /></button>
                <span className="nt-text text-[12px] font-medium opacity-80">Добавить</span>
              </div>
            </div>
          )}

          {/* виджеты */}
          {!incognito && (widgets.shield || widgets.notes) && (
            <div className="mt-12 w-full max-w-[760px] grid gap-4 animate-rise" style={{ gridTemplateColumns: widgets.shield && widgets.notes ? "repeat(auto-fit, minmax(280px, 1fr))" : "1fr", animationDelay: "180ms" }}>
              {widgets.shield && (
                <div className="widget p-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.2)" }}><ShieldCheck size={22} /></div>
                    <div>
                      <div className="text-[14px] font-semibold">Защита Aera</div>
                      <div className="text-[12px] opacity-70">{settings.blockAds ? "Активна" : "Блокировщик выключен"}</div>
                    </div>
                    <div className="ml-auto"><Switch checked={settings.blockAds} onChange={(v) => b.setSetting("blockAds", v)} label="Блокировщик" /></div>
                  </div>
                  <div className="flex items-end gap-6 mt-5">
                    <div>
                      <div className="text-[40px] leading-none font-bold tabular-nums">{b.blocked}</div>
                      <div className="text-[12px] opacity-70 mt-1.5 flex items-center gap-1"><Ban size={12} /> заблокировано за сессию</div>
                    </div>
                    <div className="ml-auto text-right text-[12px] opacity-80 leading-relaxed">
                      <div>HTTPS-only: {settings.httpsOnly ? "вкл" : "выкл"}</div>
                      <div>Do Not Track: {settings.dnt ? "вкл" : "выкл"}</div>
                    </div>
                  </div>
                </div>
              )}
              {widgets.notes && (
                <div className="widget p-5 flex flex-col">
                  <div className="flex items-center gap-2 mb-2 text-[14px] font-semibold"><StickyNote size={16} /> Заметки</div>
                  <textarea
                    value={b.notes} onChange={(e) => b.setNotes(e.target.value)} placeholder="Быстрая заметка…" spellCheck={false}
                    className="flex-1 min-h-[84px] resize-none bg-transparent border-0 text-[13.5px] leading-relaxed placeholder:text-white/50 select-text"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* кнопка правки */}
      {!edit && !incognito && (
        <button
          className="absolute bottom-5 right-5 flex items-center gap-2 h-9 px-4 rounded-full text-[13px] font-medium text-white transition-all hover:scale-105 active:scale-95"
          style={{ background: "rgba(0,0,0,0.28)", border: "1px solid rgba(255,255,255,0.25)", backdropFilter: "blur(14px)" }}
          onClick={() => setEdit(true)}
        ><SlidersHorizontal size={14} /> Настроить</button>
      )}

      {edit && <EditPanel onDone={() => setEdit(false)} />}
      {engMenu && (
        <ContextMenu
          x={engMenu.x} y={engMenu.y} onClose={() => setEngMenu(null)}
          items={(Object.keys(ENGINES) as EngineId[]).map((id) => ({
            label: ENGINES[id].name, icon: settings.engine === id ? <Check size={14} /> : undefined, onClick: () => b.setSetting("engine", id),
          }))}
        />
      )}
      {adding && <DialEditor id={adding.id} onClose={() => setAdding(null)} />}
    </div>
  );
}

function EditPanel({ onDone }: { onDone: () => void }) {
  const b = useBrowser();
  const { widgets, settings } = b;
  const fileRef = useRef<HTMLInputElement>(null);
  const toggles: [keyof typeof widgets, string][] = [["clock", "Часы"], ["dial", "Быстрые ссылки"], ["shield", "Защита"], ["notes", "Заметки"]];

  const upload = (f?: File) => {
    if (!f) return;
    if (f.size > 3_500_000) { b.toast("Файл слишком большой (до 3.5 МБ)", "warn"); return; }
    const r = new FileReader();
    r.onload = () => { b.setSetting("customWallpaper", String(r.result)); b.setSetting("wallpaper", "custom"); };
    r.readAsDataURL(f);
  };

  return (
    <div
      className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 menu !p-4 w-[min(640px,calc(100%-32px))] animate-pop"
      style={{ transformOrigin: "bottom center" }}
    >
      <div className="flex items-center mb-3">
        <div className="text-[14px] font-semibold flex items-center gap-2"><Pencil size={14} /> Режим правки</div>
        <span className="text-[12px] t3 ml-3">тяните плитки · клик — изменить</span>
        <button className="btn primary ml-auto" onClick={onDone}><Check size={14} /> Готово</button>
      </div>
      <div className="flex flex-wrap gap-2 mb-4">
        {toggles.map(([k, label]) => (
          <button
            key={k} onClick={() => b.setWidgets({ ...widgets, [k]: !widgets[k] })}
            className="h-8 px-3.5 rounded-full text-[12.5px] font-medium border transition-all"
            style={widgets[k] ? { background: "var(--accent)", color: "#fff", borderColor: "transparent" } : { borderColor: "var(--hairline-strong)", color: "var(--text-2)" }}
          >{widgets[k] && <Check size={12} className="inline mr-1 -mt-0.5" />}{label}</button>
        ))}
      </div>
      <div className="text-[11px] font-semibold uppercase tracking-wider t3 mb-2">Обои</div>
      <div className="flex gap-2 flex-wrap">
        {WALLPAPERS.map((w) => (
          <button
            key={w.id} title={w.name} onClick={() => b.setSetting("wallpaper", w.id)}
            className="w-11 h-11 rounded-xl transition-transform hover:scale-110 flex items-center justify-center text-white"
            style={{ background: w.css, boxShadow: settings.wallpaper === w.id ? "0 0 0 2px var(--toolbar-bg), 0 0 0 4px var(--accent)" : "inset 0 0 0 1px rgba(255,255,255,0.2)" }}
          >{settings.wallpaper === w.id && <Check size={16} />}</button>
        ))}
        <button
          title="Своё фото" onClick={() => fileRef.current?.click()}
          className="w-11 h-11 rounded-xl flex items-center justify-center t2 transition-transform hover:scale-110"
          style={{ background: settings.wallpaper === "custom" && settings.customWallpaper ? `center / cover url(${settings.customWallpaper})` : "var(--glass-soft)", boxShadow: settings.wallpaper === "custom" ? "0 0 0 2px var(--toolbar-bg), 0 0 0 4px var(--accent)" : undefined }}
        ><ImagePlus size={18} /></button>
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => upload(e.target.files?.[0])} />
      </div>
    </div>
  );
}

function DialEditor({ id, onClose }: { id?: string; onClose: () => void }) {
  const b = useBrowser();
  const ex = id ? b.dial.find((d) => d.id === id) : undefined;
  const [title, setTitle] = useState(ex?.title ?? "");
  const [url, setUrl] = useState(ex?.url ?? "");
  const ref = useRef<HTMLFormElement>(null);
  useOutside(ref, onClose);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    const full = normalizeInput(url, "duckduckgo", false);
    const t = title.trim() || hostOf(full) || full;
    b.setDial(ex ? b.dial.map((d) => (d.id === ex.id ? { ...d, title: t, url: full } : d)) : [...b.dial, { id: uid(), title: t, url: full }]);
    onClose();
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center animate-fade" style={{ background: "rgba(0,0,0,0.35)" }}>
      <form ref={ref} onSubmit={save} className="menu !p-5 w-[380px] !transform-none" style={{ transformOrigin: "center" }}>
        <h3 className="text-[16px] font-semibold mb-4">{ex ? "Изменить ссылку" : "Новая быстрая ссылка"}</h3>
        <label className="text-[12px] t2 block mb-1">Адрес</label>
        <input autoFocus className="field w-full mb-3" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="example.com" />
        <label className="text-[12px] t2 block mb-1">Название</label>
        <input className="field w-full mb-5" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Необязательно" />
        <div className="flex justify-end gap-2">
          <button type="button" className="btn" onClick={onClose}>Отмена</button>
          <button type="submit" className="btn primary">Сохранить</button>
        </div>
      </form>
    </div>
  );
}
