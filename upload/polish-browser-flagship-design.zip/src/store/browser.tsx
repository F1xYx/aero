import {
  createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode,
} from "react";
import type {
  Bookmark, Credential, DialItem, Download, HistoryItem, Settings, Tab, Toast,
} from "../lib/types";
import { NEWTAB, isInternal, normalizeInput, titleFor, uid } from "../lib/url";

/* ---------------- persistence ---------------- */
function usePersist<T>(key: string, init: T) {
  const [v, setV] = useState<T>(() => {
    try {
      const raw = localStorage.getItem("aera." + key);
      if (raw) return { ...(typeof init === "object" && !Array.isArray(init) ? init : {}), ...JSON.parse(raw) } as T;
    } catch { /* noop */ }
    return init;
  });
  useEffect(() => {
    try { localStorage.setItem("aera." + key, JSON.stringify(v)); } catch { /* quota */ }
  }, [key, v]);
  return [v, setV] as const;
}

function usePersistList<T>(key: string, init: T[]) {
  const [v, setV] = useState<T[]>(() => {
    try {
      const raw = localStorage.getItem("aera." + key);
      if (raw) return JSON.parse(raw) as T[];
    } catch { /* noop */ }
    return init;
  });
  useEffect(() => {
    try { localStorage.setItem("aera." + key, JSON.stringify(v)); } catch { /* quota */ }
  }, [key, v]);
  return [v, setV] as const;
}

/* ---------------- defaults ---------------- */
export const DEFAULT_SETTINGS: Settings = {
  theme: "system", accent: "default", wallpaper: "golden", customWallpaper: "",
  glass: true, animations: true, uiScale: 100,
  startup: "newtab", homepage: "", engine: "duckduckgo", suggestions: true,
  defaultZoom: 100, sleepTabs: true, newTabAfterCurrent: true, closeOnDblClick: false, wheelSwitch: true,
  bookmarksBar: true, blockAds: true, httpsOnly: true, dnt: true, noReferrer: true,
  blockThirdCookies: true, saveHistory: true, askDownload: false,
};

const DEFAULT_BOOKMARKS: Bookmark[] = [
  { id: "b1", title: "Aera на GitHub", url: "https://github.com/F1xYx/aera" },
  { id: "b2", title: "Википедия", url: "https://ru.wikipedia.org" },
  { id: "b3", title: "MDN", url: "https://developer.mozilla.org" },
  { id: "b4", title: "OpenStreetMap", url: "https://www.openstreetmap.org" },
  { id: "b5", title: "Хабр", url: "https://habr.com" },
];

const DEFAULT_DIAL: DialItem[] = [
  { id: "d1", title: "Aera", url: "https://github.com/F1xYx/aera" },
  { id: "d2", title: "Википедия", url: "https://ru.wikipedia.org" },
  { id: "d3", title: "YouTube", url: "https://www.youtube.com" },
  { id: "d4", title: "GitHub", url: "https://github.com" },
  { id: "d5", title: "Хабр", url: "https://habr.com" },
  { id: "d6", title: "MDN", url: "https://developer.mozilla.org" },
  { id: "d7", title: "OpenStreetMap", url: "https://www.openstreetmap.org" },
];

export interface Widgets { clock: boolean; shield: boolean; notes: boolean; dial: boolean }
const DEFAULT_WIDGETS: Widgets = { clock: true, shield: true, notes: true, dial: true };

const makeTab = (url: string, o: { incognito?: boolean; zoom?: number; pinned?: boolean } = {}): Tab => ({
  id: uid(), stack: [url], pos: 0, title: titleFor(url), pinned: !!o.pinned, muted: false,
  loading: !isInternal(url), sleeping: false, incognito: !!o.incognito, zoom: o.zoom ?? 100,
  reloadKey: 0, lastActive: Date.now(), blocked: 0,
});

/* ---------------- context ---------------- */
interface Ctx {
  settings: Settings;
  setSetting: <K extends keyof Settings>(k: K, v: Settings[K]) => void;
  resetSettings: () => void;

  tabs: Tab[];
  active: Tab;
  newTab: (url?: string, o?: { background?: boolean; incognito?: boolean }) => string;
  closeTab: (id: string) => void;
  closeOthers: (id: string) => void;
  closeRight: (id: string) => void;
  restoreTab: () => void;
  canRestore: boolean;
  activate: (id: string) => void;
  cycle: (dir: 1 | -1) => void;
  activateIndex: (i: number) => void;
  open: (input: string, id?: string) => void;
  navigate: (url: string, id?: string) => void;
  go: (delta: -1 | 1) => void;
  reload: (id?: string) => void;
  stop: () => void;
  markLoaded: (id: string, url: string) => void;
  togglePin: (id: string) => void;
  toggleMute: (id: string) => void;
  duplicate: (id: string) => void;
  moveTab: (from: number, to: number) => void;
  zoom: (d: number | "reset") => void;
  goHome: () => void;
  openPage: (url: string) => void;

  bookmarks: Bookmark[];
  isBookmarked: (url: string) => boolean;
  toggleBookmark: (url?: string, title?: string) => void;
  addBookmark: (title: string, url: string) => void;
  removeBookmark: (id: string) => void;

  history: HistoryItem[];
  clearHistory: () => void;
  removeHistory: (id: string) => void;

  downloads: Download[];
  addDownload: (name: string, blob: Blob) => void;
  removeDownload: (id: string) => void;
  clearDownloads: () => void;

  passwords: Credential[];
  addPassword: (c: Omit<Credential, "id">) => void;
  removePassword: (id: string) => void;

  extensions: Record<string, boolean>;
  installExtension: (id: string) => void;
  toggleExtension: (id: string) => void;
  removeExtension: (id: string) => void;

  dial: DialItem[];
  setDial: (d: DialItem[]) => void;
  widgets: Widgets;
  setWidgets: (w: Widgets) => void;
  notes: string;
  setNotes: (s: string) => void;

  blocked: number;
  toasts: Toast[];
  toast: (text: string, kind?: Toast["kind"]) => void;

  findOpen: boolean;
  setFindOpen: (b: boolean) => void;
  focusOmnibox: () => void;
}

const BrowserCtx = createContext<Ctx | null>(null);
export const useBrowser = () => {
  const c = useContext(BrowserCtx);
  if (!c) throw new Error("BrowserProvider missing");
  return c;
};

export function BrowserProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = usePersist<Settings>("settings", DEFAULT_SETTINGS);
  const [bookmarks, setBookmarks] = usePersistList<Bookmark>("bookmarks", DEFAULT_BOOKMARKS);
  const [history, setHistory] = usePersistList<HistoryItem>("history", []);
  const [downloads, setDownloads] = usePersistList<Download>("downloads", []);
  const [passwords, setPasswords] = usePersistList<Credential>("passwords", []);
  const [extensions, setExtensions] = usePersist<Record<string, boolean>>("extensions", {});
  const [dial, setDial] = usePersistList<DialItem>("dial", DEFAULT_DIAL);
  const [widgets, setWidgets] = usePersist<Widgets>("widgets", DEFAULT_WIDGETS);
  const [notes, setNotes] = usePersist<{ t: string }>("notes", { t: "" });

  const [tabs, setTabs] = useState<Tab[]>(() => {
    if (settings.startup === "restore") {
      try {
        const raw = JSON.parse(localStorage.getItem("aera.session") || "[]") as Tab[];
        if (raw.length) return raw.map((t) => ({ ...t, loading: false, sleeping: !isInternal(t.stack[t.pos]), lastActive: Date.now() }));
      } catch { /* noop */ }
    }
    return [makeTab(NEWTAB, { zoom: settings.defaultZoom })];
  });
  const [activeId, setActiveId] = useState(() => tabs[0].id);
  const [closed, setClosed] = useState<{ url: string; pinned: boolean }[]>([]);
  const [blocked, setBlocked] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [findOpen, setFindOpen] = useState(false);

  const tabsRef = useRef(tabs); tabsRef.current = tabs;
  const activeRef = useRef(activeId); activeRef.current = activeId;
  const settingsRef = useRef(settings); settingsRef.current = settings;

  const commitTabs = (next: Tab[]) => { tabsRef.current = next; setTabs(next); };
  const commitActive = (id: string) => { activeRef.current = id; setActiveId(id); };
  const patch = (id: string, p: Partial<Tab> | ((t: Tab) => Partial<Tab>)) =>
    commitTabs(tabsRef.current.map((t) => (t.id === id ? { ...t, ...(typeof p === "function" ? p(t) : p) } : t)));

  const active = tabs.find((t) => t.id === activeId) ?? tabs[0];

  /* ---------- toasts ---------- */
  const toast = useCallback((text: string, kind: Toast["kind"] = "info") => {
    const id = uid();
    setToasts((t) => [...t.slice(-3), { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  /* ---------- settings ---------- */
  const setSetting: Ctx["setSetting"] = (k, v) => setSettings((s) => ({ ...s, [k]: v }));
  const resetSettings = () => { setSettings(DEFAULT_SETTINGS); toast("Настройки сброшены", "ok"); };

  /* ---------- применение оформления ---------- */
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = settings.theme === "dark" || (settings.theme === "system" && mq.matches);
      document.documentElement.dataset.theme = dark ? "dark" : "light";
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [settings.theme]);
  useEffect(() => {
    const d = document.documentElement.dataset;
    d.accent = settings.accent;
    d.glass = settings.glass ? "on" : "off";
    d.anim = settings.animations ? "on" : "off";
  }, [settings.accent, settings.glass, settings.animations]);

  /* ---------- сессия + сон вкладок ---------- */
  useEffect(() => {
    try {
      localStorage.setItem(
        "aera.session",
        JSON.stringify(tabs.filter((t) => !t.incognito).map((t) => ({ ...t, loading: false }))),
      );
    } catch { /* noop */ }
  }, [tabs]);

  useEffect(() => {
    const iv = setInterval(() => {
      if (!settingsRef.current.sleepTabs) return;
      const now = Date.now();
      const cur = tabsRef.current;
      if (cur.some((t) => t.id !== activeRef.current && !t.sleeping && !isInternal(t.stack[t.pos]) && now - t.lastActive > 120000)) {
        commitTabs(cur.map((t) =>
          t.id !== activeRef.current && !t.sleeping && !isInternal(t.stack[t.pos]) && now - t.lastActive > 120000
            ? { ...t, sleeping: true, loading: false } : t));
      }
    }, 15000);
    return () => clearInterval(iv);
  }, []);

  /* ---------- вкладки ---------- */
  const newTab: Ctx["newTab"] = (url = NEWTAB, o = {}) => {
    const t = makeTab(url, { incognito: o.incognito, zoom: settingsRef.current.defaultZoom });
    const cur = tabsRef.current;
    const idx = cur.findIndex((x) => x.id === activeRef.current);
    let at = cur.length;
    if (settingsRef.current.newTabAfterCurrent && idx >= 0) {
      at = idx + 1;
      while (at < cur.length && cur[at].pinned && !cur[idx].pinned) at++;
    }
    commitTabs([...cur.slice(0, at), t, ...cur.slice(at)]);
    if (!o.background) commitActive(t.id);
    return t.id;
  };

  const activate = (id: string) => {
    if (!tabsRef.current.some((t) => t.id === id)) return;
    commitActive(id);
    patch(id, (t) => ({ lastActive: Date.now(), sleeping: false, loading: t.sleeping && !isInternal(t.stack[t.pos]) ? true : t.loading }));
  };

  const closeTab = (id: string) => {
    const cur = tabsRef.current;
    const i = cur.findIndex((t) => t.id === id);
    if (i < 0) return;
    const t = cur[i];
    const url = t.stack[t.pos];
    if (!t.incognito && url !== NEWTAB) setClosed((c) => [...c.slice(-19), { url, pinned: t.pinned }]);
    if (cur.length === 1) {
      const fresh = makeTab(NEWTAB, { zoom: settingsRef.current.defaultZoom });
      commitTabs([fresh]); commitActive(fresh.id);
      return;
    }
    const next = cur.filter((x) => x.id !== id);
    commitTabs(next);
    if (activeRef.current === id) activate((cur[i + 1] ?? cur[i - 1]).id);
  };

  const closeOthers = (id: string) => {
    const keep = tabsRef.current.filter((t) => t.id === id || t.pinned);
    commitTabs(keep); commitActive(id);
  };
  const closeRight = (id: string) => {
    const cur = tabsRef.current;
    const i = cur.findIndex((t) => t.id === id);
    const keep = cur.filter((t, j) => j <= i || t.pinned);
    commitTabs(keep);
    if (!keep.some((t) => t.id === activeRef.current)) commitActive(id);
  };

  const restoreTab = () => {
    const last = closed[closed.length - 1];
    if (!last) { toast("Нет закрытых вкладок"); return; }
    setClosed((c) => c.slice(0, -1));
    newTab(last.url);
    toast("Вкладка восстановлена", "ok");
  };

  const cycle = (dir: 1 | -1) => {
    const cur = tabsRef.current;
    const i = cur.findIndex((t) => t.id === activeRef.current);
    activate(cur[(i + dir + cur.length) % cur.length].id);
  };
  const activateIndex = (i: number) => {
    const cur = tabsRef.current;
    activate((i >= 8 ? cur[cur.length - 1] : cur[i])?.id ?? cur[0].id);
  };

  const navigate: Ctx["navigate"] = (url, id = activeRef.current) => {
    const s = settingsRef.current;
    const ext = !isInternal(url);
    const n = ext && s.blockAds ? 2 + Math.floor(Math.random() * 22) : 0;
    if (n) setBlocked((b) => b + n);
    patch(id, (t) => {
      if (t.stack[t.pos] === url && ext) return { reloadKey: t.reloadKey + 1, loading: true, blocked: n, sleeping: false };
      const stack = [...t.stack.slice(0, t.pos + 1), url];
      return { stack, pos: stack.length - 1, title: titleFor(url), loading: ext, blocked: n, sleeping: false, lastActive: Date.now() };
    });
  };

  const open: Ctx["open"] = (input, id) => {
    const s = settingsRef.current;
    const url = normalizeInput(input, s.engine, s.httpsOnly);
    navigate(url, id);
  };

  const go = (delta: -1 | 1) => {
    patch(activeRef.current, (t) => {
      const pos = Math.min(Math.max(t.pos + delta, 0), t.stack.length - 1);
      if (pos === t.pos) return {};
      const url = t.stack[pos];
      return { pos, title: titleFor(url), loading: !isInternal(url), sleeping: false, reloadKey: t.reloadKey + 1 };
    });
  };

  const reload = (id = activeRef.current) =>
    patch(id, (t) => ({ reloadKey: t.reloadKey + 1, loading: !isInternal(t.stack[t.pos]), sleeping: false }));
  const stop = () => patch(activeRef.current, { loading: false });

  const markLoaded = (id: string, url: string) => {
    const t = tabsRef.current.find((x) => x.id === id);
    if (!t || !t.loading) return;
    patch(id, { loading: false });
    if (!t.incognito && settingsRef.current.saveHistory && !isInternal(url)) {
      setHistory((h) => (h[0]?.url === url ? h : [{ id: uid(), title: titleFor(url), url, time: Date.now() }, ...h].slice(0, 500)));
    }
  };

  const togglePin = (id: string) => {
    const cur = tabsRef.current.map((t) => (t.id === id ? { ...t, pinned: !t.pinned } : t));
    commitTabs([...cur.filter((t) => t.pinned), ...cur.filter((t) => !t.pinned)]);
  };
  const toggleMute = (id: string) => patch(id, (t) => ({ muted: !t.muted }));
  const duplicate = (id: string) => {
    const src = tabsRef.current.find((t) => t.id === id);
    if (!src) return;
    const cur = tabsRef.current;
    const i = cur.findIndex((t) => t.id === id);
    const t: Tab = { ...makeTab(src.stack[src.pos], { incognito: src.incognito, zoom: src.zoom }) };
    commitTabs([...cur.slice(0, i + 1), t, ...cur.slice(i + 1)]);
    commitActive(t.id);
  };
  const moveTab = (from: number, to: number) => {
    if (from === to) return;
    const cur = [...tabsRef.current];
    if (cur[from].pinned !== cur[to].pinned) return;
    const [t] = cur.splice(from, 1);
    cur.splice(to, 0, t);
    commitTabs(cur);
  };
  const zoom = (d: number | "reset") =>
    patch(activeRef.current, (t) => ({ zoom: d === "reset" ? settingsRef.current.defaultZoom : Math.min(300, Math.max(30, t.zoom + d)) }));
  const goHome = () => {
    const h = settingsRef.current.homepage.trim();
    navigate(h ? normalizeInput(h, settingsRef.current.engine, settingsRef.current.httpsOnly) : NEWTAB);
  };

  const openPage = (url: string) => {
    const ex = tabsRef.current.find((t) => t.stack[t.pos] === url);
    if (ex) { activate(ex.id); return; }
    const cur = tabsRef.current.find((t) => t.id === activeRef.current);
    if (cur && cur.stack[cur.pos] === NEWTAB) navigate(url);
    else newTab(url);
  };

  /* ---------- закладки ---------- */
  const isBookmarked = (url: string) => bookmarks.some((b) => b.url === url);
  const toggleBookmark = (url = active.stack[active.pos], title = active.title) => {
    if (isInternal(url)) { toast("Эту страницу нельзя добавить в закладки"); return; }
    if (isBookmarked(url)) {
      setBookmarks((b) => b.filter((x) => x.url !== url));
      toast("Закладка удалена");
    } else {
      setBookmarks((b) => [...b, { id: uid(), title, url }]);
      toast("Добавлено в закладки", "ok");
    }
  };
  const addBookmark = (title: string, url: string) => setBookmarks((b) => [...b, { id: uid(), title, url }]);
  const removeBookmark = (id: string) => setBookmarks((b) => b.filter((x) => x.id !== id));

  /* ---------- история/загрузки/пароли/расширения ---------- */
  const clearHistory = () => { setHistory([]); toast("История очищена", "ok"); };
  const removeHistory = (id: string) => setHistory((h) => h.filter((x) => x.id !== id));

  const addDownload = (name: string, blob: Blob) => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    setDownloads((d) => [{ id: uid(), name, size: blob.size, time: Date.now(), state: "done", progress: 100 }, ...d]);
    toast(`Загружено: ${name}`, "ok");
  };
  const removeDownload = (id: string) => setDownloads((d) => d.filter((x) => x.id !== id));
  const clearDownloads = () => setDownloads([]);

  const addPassword = (c: Omit<Credential, "id">) => { setPasswords((p) => [{ ...c, id: uid() }, ...p]); toast("Пароль сохранён", "ok"); };
  const removePassword = (id: string) => setPasswords((p) => p.filter((x) => x.id !== id));

  const installExtension = (id: string) => { setExtensions((e) => ({ ...e, [id]: true })); toast("Расширение установлено", "ok"); };
  const toggleExtension = (id: string) => setExtensions((e) => ({ ...e, [id]: !e[id] }));
  const removeExtension = (id: string) => {
    setExtensions((e) => { const n = { ...e }; delete n[id]; return n; });
    toast("Расширение удалено");
  };

  const focusOmnibox = () => window.dispatchEvent(new Event("aera:focus-omnibox"));

  const value: Ctx = {
    settings, setSetting, resetSettings,
    tabs, active, newTab, closeTab, closeOthers, closeRight, restoreTab, canRestore: closed.length > 0,
    activate, cycle, activateIndex, open, navigate, go, reload, stop, markLoaded,
    togglePin, toggleMute, duplicate, moveTab, zoom, goHome, openPage,
    bookmarks, isBookmarked, toggleBookmark, addBookmark, removeBookmark,
    history, clearHistory, removeHistory,
    downloads, addDownload, removeDownload, clearDownloads,
    passwords, addPassword, removePassword,
    extensions, installExtension, toggleExtension, removeExtension,
    dial, setDial, widgets, setWidgets, notes: notes.t, setNotes: (t) => setNotes({ t }),
    blocked, toasts, toast, findOpen, setFindOpen, focusOmnibox,
  };

  return <BrowserCtx.Provider value={value}>{children}</BrowserCtx.Provider>;
}
