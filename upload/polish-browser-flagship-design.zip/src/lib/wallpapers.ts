export interface Wallpaper { id: string; name: string; css: string }

export const WALLPAPERS: Wallpaper[] = [
  {
    id: "golden",
    name: "Golden Gate",
    css: "radial-gradient(900px 600px at 85% -5%, #ffd29a 0%, transparent 60%), radial-gradient(800px 600px at 5% 105%, #6a4cff 0%, transparent 62%), linear-gradient(160deg, #ff8a5c 0%, #c2467a 48%, #3a2a7c 100%)",
  },
  {
    id: "aurora",
    name: "Аврора",
    css: "radial-gradient(800px 500px at 20% 0%, #3be8b0 0%, transparent 60%), radial-gradient(900px 600px at 90% 80%, #7a5cff 0%, transparent 60%), linear-gradient(180deg, #0b1d3a, #0a2a3f 60%, #14304a)",
  },
  {
    id: "ocean",
    name: "Океан",
    css: "radial-gradient(900px 600px at 80% 10%, #5ee0ff 0%, transparent 55%), linear-gradient(170deg, #1d6fe0 0%, #123e9c 55%, #0a1f5c 100%)",
  },
  {
    id: "forest",
    name: "Лес",
    css: "radial-gradient(900px 600px at 15% 10%, #b8f08a 0%, transparent 55%), linear-gradient(165deg, #3b9a5e 0%, #1c5a4a 55%, #0d2f33 100%)",
  },
  {
    id: "sakura",
    name: "Сакура",
    css: "radial-gradient(900px 600px at 80% 0%, #ffd1e3 0%, transparent 60%), linear-gradient(160deg, #ff8fb8 0%, #d6579c 55%, #6c2f7e 100%)",
  },
  {
    id: "dune",
    name: "Дюны",
    css: "radial-gradient(900px 500px at 50% 0%, #ffe3a8 0%, transparent 60%), linear-gradient(175deg, #f2a65a 0%, #c9693a 55%, #6b2f2a 100%)",
  },
  {
    id: "graphite",
    name: "Графит",
    css: "radial-gradient(900px 600px at 70% 0%, #4a4a58 0%, transparent 60%), linear-gradient(170deg, #2a2a33 0%, #17171d 100%)",
  },
  {
    id: "mono",
    name: "Нуар",
    css: "radial-gradient(700px 500px at 50% 30%, #23233a 0%, transparent 70%), #08080c",
  },
];

export const wallpaperCss = (id: string, custom: string) =>
  id === "custom" && custom ? `center / cover no-repeat url(${custom})` : (WALLPAPERS.find((w) => w.id === id) ?? WALLPAPERS[0]).css;
