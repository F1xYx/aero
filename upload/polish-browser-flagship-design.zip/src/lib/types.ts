export type ThemePref = "system" | "light" | "dark";
export type Accent =
  | "default" | "sunset" | "sakura" | "mint" | "golden" | "lavender" | "crimson" | "graphite";
export type EngineId = "google" | "duckduckgo" | "bing" | "yandex" | "brave";

export interface Settings {
  theme: ThemePref;
  accent: Accent;
  wallpaper: string;
  customWallpaper: string;
  glass: boolean;
  animations: boolean;
  uiScale: number;
  startup: "newtab" | "restore";
  homepage: string;
  engine: EngineId;
  suggestions: boolean;
  defaultZoom: number;
  sleepTabs: boolean;
  newTabAfterCurrent: boolean;
  closeOnDblClick: boolean;
  wheelSwitch: boolean;
  bookmarksBar: boolean;
  blockAds: boolean;
  httpsOnly: boolean;
  dnt: boolean;
  noReferrer: boolean;
  blockThirdCookies: boolean;
  saveHistory: boolean;
  askDownload: boolean;
}

export interface Tab {
  id: string;
  stack: string[];
  pos: number;
  title: string;
  pinned: boolean;
  muted: boolean;
  loading: boolean;
  sleeping: boolean;
  incognito: boolean;
  zoom: number;
  reloadKey: number;
  lastActive: number;
  blocked: number;
}

export interface Bookmark { id: string; title: string; url: string }
export interface HistoryItem { id: string; title: string; url: string; time: number }
export interface Download {
  id: string; name: string; size: number; time: number; state: "done" | "progress" | "cancelled"; progress: number;
}
export interface Credential { id: string; site: string; user: string; pass: string }
export interface DialItem { id: string; title: string; url: string }
export interface Toast { id: string; text: string; kind: "info" | "ok" | "warn" }
