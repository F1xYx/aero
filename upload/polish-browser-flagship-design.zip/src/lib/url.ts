import type { EngineId } from "./types";

export const ENGINES: Record<EngineId, { name: string; url: string; home: string }> = {
  google: { name: "Google", url: "https://www.google.com/search?q=%s&igu=1", home: "google.com" },
  duckduckgo: { name: "DuckDuckGo", url: "https://duckduckgo.com/?q=%s", home: "duckduckgo.com" },
  bing: { name: "Bing", url: "https://www.bing.com/search?q=%s", home: "bing.com" },
  yandex: { name: "Яндекс", url: "https://yandex.ru/search/?text=%s", home: "yandex.ru" },
  brave: { name: "Brave Search", url: "https://search.brave.com/search?q=%s", home: "search.brave.com" },
};

export const INTERNAL_PAGES: Record<string, { title: string; keywords: string }> = {
  "aera://newtab": { title: "Новая вкладка", keywords: "новая вкладка start home главная" },
  "aera://settings": { title: "Настройки", keywords: "настройки settings параметры" },
  "aera://history": { title: "История", keywords: "история history" },
  "aera://downloads": { title: "Загрузки", keywords: "загрузки downloads файлы" },
  "aera://bookmarks": { title: "Закладки", keywords: "закладки bookmarks избранное" },
  "aera://passwords": { title: "Пароли", keywords: "пароли passwords" },
  "aera://extensions": { title: "Магазин расширений", keywords: "расширения extensions store плагины" },
};

export const NEWTAB = "aera://newtab";
export const isInternal = (u: string) => u.startsWith("aera://");

export const POPULAR = [
  "youtube.com", "wikipedia.org", "github.com", "reddit.com", "twitter.com", "x.com", "habr.com",
  "stackoverflow.com", "openstreetmap.org", "news.ycombinator.com", "vk.com", "telegram.org",
  "netflix.com", "twitch.tv", "spotify.com", "figma.com", "npmjs.com", "developer.mozilla.org",
];

const IP_RE = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?(\/.*)?$/;

export function normalizeInput(raw: string, engine: EngineId, httpsOnly: boolean): string {
  const v = raw.trim();
  if (!v) return NEWTAB;
  if (v.startsWith("aera://")) return v;
  if (/^(javascript|data|file|about):/i.test(v)) return `${ENGINES[engine].url.replace("%s", encodeURIComponent(v))}`;
  if (/^https?:\/\//i.test(v)) return httpsOnly ? v.replace(/^http:\/\//i, "https://") : v;
  const looksLikeHost =
    !/\s/.test(v) && (/^[^\s/]+\.[a-z]{2,}([/:?#].*)?$/i.test(v) || /^localhost(:\d+)?(\/.*)?$/i.test(v) || IP_RE.test(v));
  if (looksLikeHost) {
    const local = /^(localhost|127\.|192\.168\.|10\.)/i.test(v);
    return (local ? "http://" : "https://") + v;
  }
  return ENGINES[engine].url.replace("%s", encodeURIComponent(v));
}

export function hostOf(url: string): string {
  if (isInternal(url)) return "";
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return url; }
}

export function isSecure(url: string) {
  return url.startsWith("https://") || isInternal(url);
}

/** Строка для адресной строки в состоянии покоя */
export function prettyUrl(url: string): string {
  if (url === NEWTAB) return "";
  if (isInternal(url)) return url.replace("aera://", "aera / ");
  try {
    const u = new URL(url);
    const q = u.searchParams.get("q") || u.searchParams.get("text");
    if (q && /search|\/\?q=/.test(url)) return q;
    return u.hostname.replace(/^www\./, "");
  } catch { return url; }
}

export function titleFor(url: string): string {
  if (isInternal(url)) return INTERNAL_PAGES[url]?.title ?? "Aera";
  const h = hostOf(url);
  try {
    const u = new URL(url);
    const q = u.searchParams.get("q") || u.searchParams.get("text");
    if (q) return `${q} — поиск`;
  } catch { /* noop */ }
  return h || url;
}

export function faviconUrl(url: string, size = 64) {
  const h = hostOf(url);
  return h ? `https://www.google.com/s2/favicons?domain=${h}&sz=${size}` : "";
}

export function colorFor(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return `hsl(${h} 62% 52%)`;
}

export function timeAgo(t: number) {
  const d = Date.now() - t;
  const m = Math.floor(d / 60000);
  if (m < 1) return "только что";
  if (m < 60) return `${m} мин назад`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ч назад`;
  return new Date(t).toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
}

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-3);

export function fmtSize(b: number) {
  if (b < 1024) return `${b} Б`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} КБ`;
  return `${(b / 1048576).toFixed(1)} МБ`;
}
